import { useState } from 'react';
import {
  Stack,
  Card,
  Group,
  Text,
  Badge,
  Button,
  ActionIcon,
  Menu,
  Progress,
  Box,
  Tabs,
  Alert,
  Checkbox,
  Textarea,
  Modal,
  LoadingOverlay,
  Accordion,
  TextInput,
  NumberInput
} from '@mantine/core';
import { useForm } from '@mantine/form';
import { useDisclosure } from '@mantine/hooks';
import {
  IconPlayerPlay,
  IconCheck,
  IconClock,
  IconAlertTriangle,
  IconDots,
  IconEdit,
  IconUsers,
  IconCalendar,
  IconFlag,
  IconTrash,
  IconPlus,
  IconEye
} from '@tabler/icons-react';
import { useProjectTasks, useCrewMemberTasks } from './project.hook';
import ProjectTaskDetailModal from './ProjectTaskDetailModal';
import type { 
  ProjectTaskWithCrew, 
  UpdateProjectTaskRequest, 
  TaskStatusType
} from './project.typs';

type TaskCategoryType = 'monitor' | 'coordinate' | 'execute';

interface ProjectTaskViewProps {
  projectId?: string;
  crewMemberId?: string;
  currentUserId: string;
  viewMode?: 'project' | 'personal';
}

interface TaskUpdateForm {
  task_name: string;
  task_description: string;
  estimated_hours: number;
  checklist_items: Array<{ text: string; completed: boolean }>;
}

export default function ProjectTaskView({
  projectId,
  crewMemberId,
  currentUserId,
  viewMode = 'project'
}: ProjectTaskViewProps) {
  const [selectedTask, setSelectedTask] = useState<ProjectTaskWithCrew | null>(null);
  const [editModalOpened, { open: openEditModal, close: closeEditModal }] = useDisclosure(false);
  const [detailModalOpened, { open: openDetailModal, close: closeDetailModal }] = useDisclosure(false);
  const [activeTab, setActiveTab] = useState<string>('all');

  // Use appropriate hook based on view mode
  const projectTasksHook = useProjectTasks(
    viewMode === 'project' ? projectId || null : null,
    { is_archived: false }
  );

  const crewTasksHook = useCrewMemberTasks(
    viewMode === 'personal' ? crewMemberId || currentUserId : null
  );

  const {
    tasks,
    loading,
    startTask,
    completeTask,
    updateTask
  } = viewMode === 'project' ? projectTasksHook : crewTasksHook;

  const editForm = useForm<TaskUpdateForm>({
    initialValues: {
      task_name: '',
      task_description: '',
      estimated_hours: 0,
      checklist_items: []
    }
  });

  const getStatusColor = (status: TaskStatusType) => {
    switch (status) {
      case 'pending': return 'gray';
      case 'ongoing': return 'blue';
      case 'completed': return 'green';
      case 'escalated': return 'red';
      default: return 'gray';
    }
  };

  const getCategoryColor = (category: TaskCategoryType | null) => {
    switch (category) {
      case 'monitor': return 'purple';
      case 'coordinate': return 'orange';
      case 'execute': return 'cyan';
      default: return 'gray';
    }
  };

  const handleStartTask = async (task: ProjectTaskWithCrew) => {
    try {
      await startTask(task.project_task_id, currentUserId);
    } catch (error) {
      // Error handled in hook
    }
  };

  const handleCompleteTask = async (task: ProjectTaskWithCrew) => {
    try {
      await completeTask(task.project_task_id, currentUserId);
    } catch (error) {
      // Error handled in hook
    }
  };

  const handleEditTask = (task: ProjectTaskWithCrew) => {
    setSelectedTask(task);
    editForm.setValues({
      task_name: task.task_name,
      task_description: task.task_description || '',
      estimated_hours: task.estimated_hours || 0,
      checklist_items: task.checklist_items || []
    });
    openEditModal();
  };

  const handleViewTask = (task: ProjectTaskWithCrew) => {
    setSelectedTask(task);
    openDetailModal();
  };

  const handleUpdateTask = async (values: TaskUpdateForm) => {
    if (!selectedTask) return;

    try {
      const updateData: UpdateProjectTaskRequest = {
        task_name: values.task_name,
        task_description: values.task_description,
        estimated_hours: values.estimated_hours,
        checklist_items: values.checklist_items
      };

      await updateTask(selectedTask.project_task_id, updateData, currentUserId);
      closeEditModal();
      setSelectedTask(null);
    } catch (error) {
      // Error handled in hook
    }
  };

  const getFilteredTasks = () => {
    switch (activeTab) {
      case 'pending':
        return tasks.filter(t => t.task_status === 'pending');
      case 'ongoing':
        return tasks.filter(t => t.task_status === 'ongoing');
      case 'completed':
        return tasks.filter(t => t.task_status === 'completed');
      case 'escalated':
        return tasks.filter(t => t.task_status === 'escalated');
      default:
        return tasks;
    }
  };

  const getTasksByPhase = () => {
    const filteredTasks = getFilteredTasks();
    const phases = new Map<string, ProjectTaskWithCrew[]>();
    
    filteredTasks.forEach(task => {
      const phaseKey = `${task.phase_order}-${task.phase_name}`;
      if (!phases.has(phaseKey)) {
        phases.set(phaseKey, []);
      }
      phases.get(phaseKey)!.push(task);
    });

    return Array.from(phases.entries()).map(([key, phaseTasks]) => ({
      phase: key.split('-').slice(1).join('-'),
      order: parseInt(key.split('-')[0]),
      tasks: phaseTasks.sort((a, b) => {
        if (a.step_order !== b.step_order) return a.step_order - b.step_order;
        return a.task_order - b.task_order;
      })
    })).sort((a, b) => a.order - b.order);
  };

  const TaskCard = ({ task }: { task: ProjectTaskWithCrew }) => (
    <Card withBorder p="md">
      <Stack gap="sm">
        <Group justify="space-between">
          <Box style={{ flex: 1 }}>
            <Group gap="xs" mb="xs">
              <Text fw={600} size="sm" lineClamp={1}>
                {task.task_name}
              </Text>
              {task.is_critical && (
                <IconFlag size={14} color="red" />
              )}
            </Group>
            
            <Group gap="xs" mb="sm">
              <Badge size="xs" color={getStatusColor(task.task_status)}>
                {task.task_status}
              </Badge>
              {task.category && (
                <Badge size="xs" color={getCategoryColor(task.category)} variant="light">
                  {task.category}
                </Badge>
              )}
            </Group>

            {task.task_description && (
              <Text size="sm" c="dimmed" lineClamp={2} mb="sm">
                {task.task_description}
              </Text>
            )}

            <Group gap="md" mb="sm">
              {task.estimated_hours && (
                <Group gap={4}>
                  <IconClock size={12} />
                  <Text size="xs" c="dimmed">
                    {task.estimated_hours}h estimated
                  </Text>
                </Group>
              )}
              
              {task.assigned_role_name && (
                <Group gap={4}>
                  <IconUsers size={12} />
                  <Text size="xs" c="dimmed">
                    {task.assigned_role_name}
                  </Text>
                </Group>
              )}

              {task.expected_end_time && (
                <Group gap={4}>
                  <IconCalendar size={12} />
                  <Text size="xs" c="dimmed">
                    Due {new Date(task.expected_end_time).toLocaleDateString()}
                  </Text>
                </Group>
              )}
            </Group>

            {/* Checklist Progress */}
            {task.checklist_items && task.checklist_items.length > 0 && (
              <Box mb="sm">
                <Group justify="space-between" mb={4}>
                  <Text size="xs" fw={500}>Checklist</Text>
                  <Text size="xs" c="dimmed">
                    {task.checklist_items.filter(item => item.completed).length}/{task.checklist_items.length}
                  </Text>
                </Group>
                <Progress
                  size="xs"
                  value={(task.checklist_items.filter(item => item.completed).length / task.checklist_items.length) * 100}
                  color="blue"
                />
              </Box>
            )}
          </Box>

          <Menu shadow="md" width={200}>
            <Menu.Target>
              <ActionIcon variant="subtle" color="gray">
                <IconDots size={16} />
              </ActionIcon>
            </Menu.Target>
            <Menu.Dropdown>
              <Menu.Item
                leftSection={<IconEye size={14} />}
                onClick={() => handleViewTask(task)}
              >
                View Details
              </Menu.Item>
              {task.task_status === 'pending' && (
                <Menu.Item
                  leftSection={<IconPlayerPlay size={14} />}
                  onClick={() => handleStartTask(task)}
                >
                  Start Task
                </Menu.Item>
              )}
              {task.task_status === 'ongoing' && (
                <Menu.Item
                  leftSection={<IconCheck size={14} />}
                  onClick={() => handleCompleteTask(task)}
                  color="green"
                >
                  Complete Task
                </Menu.Item>
              )}
              <Menu.Item
                leftSection={<IconEdit size={14} />}
                onClick={() => handleEditTask(task)}
              >
                Edit Task
              </Menu.Item>
            </Menu.Dropdown>
          </Menu>
        </Group>

        {/* Action Buttons */}
        <Group gap="xs">
          <Button
            size="xs"
            variant="light"
            leftSection={<IconEye size={12} />}
            onClick={() => handleViewTask(task)}
          >
            View Details
          </Button>
          {task.task_status === 'pending' && (
            <Button
              size="xs"
              leftSection={<IconPlayerPlay size={12} />}
              onClick={() => handleStartTask(task)}
            >
              Start
            </Button>
          )}
          {task.task_status === 'ongoing' && (
            <Button
              size="xs"
              color="green"
              leftSection={<IconCheck size={12} />}
              onClick={() => handleCompleteTask(task)}
            >
              Complete
            </Button>
          )}
          {task.task_status === 'escalated' && (
            <Alert color="red" p="xs">
              <Group gap={4}>
                <IconAlertTriangle size={12} />
                <Text size="xs">Escalated</Text>
              </Group>
            </Alert>
          )}
        </Group>
      </Stack>
    </Card>
  );

  const taskCounts = {
    all: tasks.length,
    pending: tasks.filter(t => t.task_status === 'pending').length,
    ongoing: tasks.filter(t => t.task_status === 'ongoing').length,
    completed: tasks.filter(t => t.task_status === 'completed').length,
    escalated: tasks.filter(t => t.task_status === 'escalated').length
  };

  return (
    <Box pos="relative">
      <LoadingOverlay visible={loading} />
      
      <Stack gap="md">
        {/* Header */}
        <Group justify="space-between">
          <Box>
            <Text size="xl" fw={600}>
              {viewMode === 'personal' ? 'My Tasks' : 'Project Tasks'}
            </Text>
            <Text size="sm" c="dimmed">
              {taskCounts.all} total tasks
            </Text>
          </Box>
        </Group>

        {/* Status Tabs */}
        <Tabs value={activeTab} onChange={(value) => setActiveTab(value || 'all')}>
          <Tabs.List>
            <Tabs.Tab value="all" rightSection={<Badge size="xs">{taskCounts.all}</Badge>}>
              All
            </Tabs.Tab>
            <Tabs.Tab value="pending" rightSection={<Badge size="xs">{taskCounts.pending}</Badge>}>
              Pending
            </Tabs.Tab>
            <Tabs.Tab value="ongoing" rightSection={<Badge size="xs">{taskCounts.ongoing}</Badge>}>
              Ongoing
            </Tabs.Tab>
            <Tabs.Tab value="completed" rightSection={<Badge size="xs">{taskCounts.completed}</Badge>}>
              Completed
            </Tabs.Tab>
            {taskCounts.escalated > 0 && (
              <Tabs.Tab value="escalated" rightSection={<Badge size="xs" color="red">{taskCounts.escalated}</Badge>}>
                Escalated
              </Tabs.Tab>
            )}
          </Tabs.List>

          <Tabs.Panel value={activeTab} pt="md">
            {getFilteredTasks().length === 0 ? (
              <Card withBorder p="xl">
                <Text ta="center" c="dimmed">
                  No tasks found for the selected filter
                </Text>
              </Card>
            ) : (
              <Accordion variant="contained">
                {getTasksByPhase().map(({ phase, tasks: phaseTasks }) => (
                  <Accordion.Item key={phase} value={phase}>
                    <Accordion.Control>
                      <Group justify="space-between" style={{ width: '100%', paddingRight: '1rem' }}>
                        <Text fw={500}>{phase}</Text>
                        <Badge size="sm">{phaseTasks.length} tasks</Badge>
                      </Group>
                    </Accordion.Control>
                    <Accordion.Panel>
                      <Stack gap="sm">
                        {phaseTasks.map(task => (
                          <TaskCard key={task.project_task_id} task={task} />
                        ))}
                      </Stack>
                    </Accordion.Panel>
                  </Accordion.Item>
                ))}
              </Accordion>
            )}
          </Tabs.Panel>
        </Tabs>

        {/* Edit Task Modal */}
        <Modal
          opened={editModalOpened}
          onClose={closeEditModal}
          title="Edit Task"
          size="lg"
        >
          <form onSubmit={editForm.onSubmit(handleUpdateTask)}>
            <Stack gap="md">
              <TextInput
                label="Task Name"
                required
                {...editForm.getInputProps('task_name')}
              />
              
              <Textarea
                label="Description"
                minRows={3}
                {...editForm.getInputProps('task_description')}
              />
              
              <NumberInput
                label="Estimated Hours"
                min={0}
                {...editForm.getInputProps('estimated_hours')}
              />

              {/* Checklist Items */}
              <Box>
                <Text size="sm" fw={500} mb="xs">Checklist Items</Text>
                <Stack gap="xs">
                  {editForm.values.checklist_items.map((item, index) => (
                    <Group key={index}>
                      <Checkbox
                        checked={item.completed}
                        onChange={(e) => {
                          const items = [...editForm.values.checklist_items];
                          items[index].completed = e.currentTarget.checked;
                          editForm.setFieldValue('checklist_items', items);
                        }}
                      />
                      <TextInput
                        style={{ flex: 1 }}
                        value={item.text}
                        onChange={(e) => {
                          const items = [...editForm.values.checklist_items];
                          items[index].text = e.target.value;
                          editForm.setFieldValue('checklist_items', items);
                        }}
                      />
                      <ActionIcon
                        color="red"
                        variant="light"
                        onClick={() => {
                          const items = editForm.values.checklist_items.filter((_, i) => i !== index);
                          editForm.setFieldValue('checklist_items', items);
                        }}
                      >
                        <IconTrash size={16} />
                      </ActionIcon>
                    </Group>
                  ))}
                  <Button
                    variant="light"
                    size="xs"
                    leftSection={<IconPlus size={12} />}
                    onClick={() => {
                      const items = [...editForm.values.checklist_items, { text: '', completed: false }];
                      editForm.setFieldValue('checklist_items', items);
                    }}
                  >
                    Add Checklist Item
                  </Button>
                </Stack>
              </Box>

              <Group justify="flex-end">
                <Button variant="light" onClick={closeEditModal}>
                  Cancel
                </Button>
                <Button type="submit">
                  Update Task
                </Button>
              </Group>
            </Stack>
          </form>
        </Modal>

        {/* Task Detail Modal */}
        <ProjectTaskDetailModal
          opened={detailModalOpened}
          onClose={closeDetailModal}
          task={selectedTask}
          currentUserId={currentUserId}
          onTaskUpdate={() => {
            if (viewMode === 'project') {
              projectTasksHook.fetchTasks();
            } else {
              crewTasksHook.fetchTasks();
            }
          }}
        />
      </Stack>
    </Box>
  );
}
