import { useState, useEffect } from 'react';
import {
  Modal,
  Stack,
  Group,
  Text,
  Badge,
  Button,
  ActionIcon,
  Tabs,
  Card,
  Box,
  Textarea,
  FileInput,
  Avatar,
  Checkbox,
  NumberInput,
  TextInput,
  Select,
  ScrollArea,
  Divider,
  Alert,
  Progress,
  LoadingOverlay,
  Anchor,
  Image
} from '@mantine/core';
import { useForm } from '@mantine/form';
import { notifications } from '@mantine/notifications';
import { useDisclosure } from '@mantine/hooks';
import {
  IconPlayerPlay,
  IconCheck,
  IconClock,
  IconUsers,
  IconCalendar,
  IconFlag,
  IconPaperclip,
  IconMessageCircle,
  IconEdit,
  IconTrash,
  IconUpload,
  IconDownload,
  IconX,
  IconPlus,
  IconSend
} from '@tabler/icons-react';
import type {
  ProjectTaskWithCrew,
  TaskComment,
  TaskAttachment,
  UpdateProjectTaskRequest,
  TaskStatusType,
  ProjectCrewWithUser
} from './project.typs';
import { 
  projectTaskService, 
  taskCommentService, 
  taskAttachmentService 
} from './project.service';
import { useProjectCrew } from './project.hook';

interface ProjectTaskDetailModalProps {
  opened: boolean;
  onClose: () => void;
  task: ProjectTaskWithCrew | null;
  currentUserId: string;
  onTaskUpdate?: () => void;
}

interface TaskUpdateForm {
  task_name: string;
  task_description: string;
  estimated_hours: number;
  checklist_items: Array<{ text: string; completed: boolean }>;
}

interface CommentForm {
  comment_text: string;
}

export default function ProjectTaskDetailModal({
  opened,
  onClose,
  task,
  currentUserId,
  onTaskUpdate
}: ProjectTaskDetailModalProps) {
  const [activeTab, setActiveTab] = useState<string>('details');
  const [comments, setComments] = useState<TaskComment[]>([]);
  const [attachments, setAttachments] = useState<TaskAttachment[]>([]);
  const [loading, setLoading] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [editModalOpened, { open: openEditModal, close: closeEditModal }] = useDisclosure(false);

  // Get project crew for assignment
  const { crew: projectCrew } = useProjectCrew(task?.project_id || null);

  const editForm = useForm<TaskUpdateForm>({
    initialValues: {
      task_name: '',
      task_description: '',
      estimated_hours: 0,
      checklist_items: []
    }
  });

  const commentForm = useForm<CommentForm>({
    initialValues: {
      comment_text: ''
    }
  });

  useEffect(() => {
    if (task && opened) {
      loadTaskDetails();
    }
  }, [task, opened]);

  const loadTaskDetails = async () => {
    if (!task) return;

    setLoading(true);
    try {
      const [commentsData, attachmentsData] = await Promise.all([
        taskCommentService.getByTask(task.project_task_id),
        taskAttachmentService.getByTask(task.project_task_id)
      ]);
      setComments(commentsData);
      setAttachments(attachmentsData);
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to load task details',
        color: 'red'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleStartTask = async () => {
    if (!task) return;
    try {
      await projectTaskService.startTask(task.project_task_id, currentUserId);
      notifications.show({
        title: 'Success',
        message: 'Task started successfully',
        color: 'green'
      });
      onTaskUpdate?.();
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to start task',
        color: 'red'
      });
    }
  };

  const handleCompleteTask = async () => {
    if (!task) return;
    try {
      await projectTaskService.completeTask(task.project_task_id, currentUserId);
      notifications.show({
        title: 'Success',
        message: 'Task completed successfully',
        color: 'green'
      });
      onTaskUpdate?.();
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to complete task',
        color: 'red'
      });
    }
  };

  const handleEditTask = () => {
    if (!task) return;
    editForm.setValues({
      task_name: task.task_name,
      task_description: task.task_description || '',
      estimated_hours: task.estimated_hours || 0,
      checklist_items: task.checklist_items || []
    });
    openEditModal();
  };

  const handleUpdateTask = async (values: TaskUpdateForm) => {
    if (!task) return;

    try {
      const updateData: UpdateProjectTaskRequest = {
        task_name: values.task_name,
        task_description: values.task_description,
        estimated_hours: values.estimated_hours,
        checklist_items: values.checklist_items
      };

      await projectTaskService.updateTask(task.project_task_id, updateData, currentUserId);
      notifications.show({
        title: 'Success',
        message: 'Task updated successfully',
        color: 'green'
      });
      closeEditModal();
      onTaskUpdate?.();
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to update task',
        color: 'red'
      });
    }
  };

  const handleAddComment = async (values: CommentForm) => {
    if (!task || !values.comment_text.trim()) return;

    try {
      const newComment = await taskCommentService.create({
        project_task_id: task.project_task_id,
        comment_text: values.comment_text
      }, currentUserId);
      
      setComments(prev => [...prev, newComment]);
      commentForm.reset();
      notifications.show({
        title: 'Success',
        message: 'Comment added successfully',
        color: 'green'
      });
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to add comment',
        color: 'red'
      });
    }
  };

  const handleFileUpload = async (file: File | null) => {
    if (!file || !task) return;

    setUploadingFile(true);
    try {
      const fileUrl = await taskAttachmentService.uploadFile(file, task.project_task_id);
      
      const attachment = await taskAttachmentService.create({
        project_task_id: task.project_task_id,
        file_name: file.name,
        file_url: fileUrl,
        file_type: file.type,
        file_size: file.size
      }, currentUserId);

      setAttachments(prev => [attachment, ...prev]);
      notifications.show({
        title: 'Success',
        message: 'File uploaded successfully',
        color: 'green'
      });
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to upload file',
        color: 'red'
      });
    } finally {
      setUploadingFile(false);
    }
  };

  const handleDeleteAttachment = async (attachmentId: string) => {
    try {
      await taskAttachmentService.delete(attachmentId);
      setAttachments(prev => prev.filter(a => a.attachment_id !== attachmentId));
      notifications.show({
        title: 'Success',
        message: 'File deleted successfully',
        color: 'green'
      });
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to delete file',
        color: 'red'
      });
    }
  };

  const handleAssignToCrew = async (projectCrewId: string) => {
    if (!task) return;

    try {
      await projectTaskService.assignToCrew({
        project_task_id: task.project_task_id,
        project_crew_id: projectCrewId
      }, currentUserId);
      
      notifications.show({
        title: 'Success',
        message: 'Task assigned successfully',
        color: 'green'
      });
      onTaskUpdate?.();
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to assign task',
        color: 'red'
      });
    }
  };

  const getStatusColor = (status: TaskStatusType) => {
    switch (status) {
      case 'pending': return 'gray';
      case 'ongoing': return 'blue';
      case 'completed': return 'green';
      case 'escalated': return 'red';
      default: return 'gray';
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const isImage = (fileType: string) => {
    return fileType.startsWith('image/');
  };

  if (!task) return null;

  const completedChecklistItems = task.checklist_items?.filter(item => item.completed).length || 0;
  const totalChecklistItems = task.checklist_items?.length || 0;
  const checklistProgress = totalChecklistItems > 0 ? (completedChecklistItems / totalChecklistItems) * 100 : 0;

  return (
    <>
      <Modal
        opened={opened}
        onClose={onClose}
        title={
          <Group>
            <Text fw={600} size="lg">{task.task_name}</Text>
            <Badge color={getStatusColor(task.task_status)}>{task.task_status}</Badge>
            {task.is_critical && <IconFlag size={16} color="red" />}
          </Group>
        }
        size="xl"
        scrollAreaComponent={ScrollArea.Autosize}
      >
        <Box pos="relative">
          <LoadingOverlay visible={loading} />
          
          <Stack gap="md">
            {/* Quick Actions */}
            <Group>
              {task.task_status === 'pending' && (
                <Button
                  leftSection={<IconPlayerPlay size={16} />}
                  onClick={handleStartTask}
                >
                  Start Task
                </Button>
              )}
              {task.task_status === 'ongoing' && (
                <Button
                  color="green"
                  leftSection={<IconCheck size={16} />}
                  onClick={handleCompleteTask}
                >
                  Complete Task
                </Button>
              )}
              <Button
                variant="light"
                leftSection={<IconEdit size={16} />}
                onClick={handleEditTask}
              >
                Edit Task
              </Button>
            </Group>

            <Tabs value={activeTab} onChange={(value) => setActiveTab(value || 'details')}>
              <Tabs.List>
                <Tabs.Tab value="details" leftSection={<IconEdit size={14} />}>
                  Details
                </Tabs.Tab>
                <Tabs.Tab value="checklist" leftSection={<IconCheck size={14} />}>
                  Checklist ({completedChecklistItems}/{totalChecklistItems})
                </Tabs.Tab>
                <Tabs.Tab value="comments" leftSection={<IconMessageCircle size={14} />}>
                  Comments ({comments.length})
                </Tabs.Tab>
                <Tabs.Tab value="attachments" leftSection={<IconPaperclip size={14} />}>
                  Files ({attachments.length})
                </Tabs.Tab>
                <Tabs.Tab value="assignment" leftSection={<IconUsers size={14} />}>
                  Assignment
                </Tabs.Tab>
              </Tabs.List>

              <Tabs.Panel value="details" pt="md">
                <Stack gap="md">
                  <Card withBorder p="md">
                    <Stack gap="sm">
                      <Text fw={500}>Description</Text>
                      <Text c="dimmed" style={{ whiteSpace: 'pre-wrap' }}>
                        {task.task_description || 'No description provided'}
                      </Text>
                    </Stack>
                  </Card>

                  <Group grow>
                    <Card withBorder p="md">
                      <Group gap="xs">
                        <IconClock size={16} />
                        <div>
                          <Text size="sm" c="dimmed">Estimated Hours</Text>
                          <Text fw={500}>{task.estimated_hours || 'Not set'}</Text>
                        </div>
                      </Group>
                    </Card>
                    
                    <Card withBorder p="md">
                      <Group gap="xs">
                        <IconCalendar size={16} />
                        <div>
                          <Text size="sm" c="dimmed">Due Date</Text>
                          <Text fw={500}>
                            {task.expected_end_time 
                              ? new Date(task.expected_end_time).toLocaleDateString()
                              : 'Not set'
                            }
                          </Text>
                        </div>
                      </Group>
                    </Card>
                  </Group>

                  <Card withBorder p="md">
                    <Stack gap="sm">
                      <Text fw={500}>Phase & Step</Text>
                      <Text c="dimmed">
                        <strong>Phase:</strong> {task.phase_name} (Order: {task.phase_order})
                      </Text>
                      <Text c="dimmed">
                        <strong>Step:</strong> {task.step_name} (Order: {task.step_order})
                      </Text>
                    </Stack>
                  </Card>
                </Stack>
              </Tabs.Panel>

              <Tabs.Panel value="checklist" pt="md">
                <Stack gap="md">
                  {totalChecklistItems > 0 && (
                    <Card withBorder p="md">
                      <Group justify="space-between" mb="sm">
                        <Text fw={500}>Progress</Text>
                        <Text size="sm" c="dimmed">
                          {completedChecklistItems}/{totalChecklistItems} completed
                        </Text>
                      </Group>
                      <Progress value={checklistProgress} color="green" size="lg" />
                    </Card>
                  )}

                  <Card withBorder p="md">
                    <Stack gap="sm">
                      <Text fw={500}>Checklist Items</Text>
                      {task.checklist_items && task.checklist_items.length > 0 ? (
                        task.checklist_items.map((item, index) => (
                          <Group key={index} align="flex-start">
                            <Checkbox
                              checked={item.completed}
                              readOnly
                              mt={2}
                            />
                            <Text 
                              style={{ 
                                textDecoration: item.completed ? 'line-through' : 'none',
                                opacity: item.completed ? 0.6 : 1
                              }}
                            >
                              {item.text}
                            </Text>
                          </Group>
                        ))
                      ) : (
                        <Text c="dimmed" ta="center">No checklist items</Text>
                      )}
                    </Stack>
                  </Card>
                </Stack>
              </Tabs.Panel>

              <Tabs.Panel value="comments" pt="md">
                <Stack gap="md">
                  <Card withBorder p="md">
                    <form onSubmit={commentForm.onSubmit(handleAddComment)}>
                      <Stack gap="sm">
                        <Textarea
                          placeholder="Add a comment..."
                          minRows={3}
                          {...commentForm.getInputProps('comment_text')}
                        />
                        <Group justify="flex-end">
                          <Button
                            type="submit"
                            size="sm"
                            leftSection={<IconSend size={14} />}
                            disabled={!commentForm.values.comment_text.trim()}
                          >
                            Add Comment
                          </Button>
                        </Group>
                      </Stack>
                    </form>
                  </Card>

                  <Stack gap="sm">
                    {comments.length > 0 ? (
                      comments.map((comment) => (
                        <Card key={comment.comment_id} withBorder p="md">
                          <Group align="flex-start">
                            <Avatar size="sm" radius="xl">
                              {comment.author_name.charAt(0).toUpperCase()}
                            </Avatar>
                            <Box style={{ flex: 1 }}>
                              <Group justify="space-between" mb="xs">
                                <Text fw={500} size="sm">{comment.author_name}</Text>
                                <Text size="xs" c="dimmed">
                                  {new Date(comment.created_at).toLocaleString()}
                                </Text>
                              </Group>
                              <Text style={{ whiteSpace: 'pre-wrap' }}>
                                {comment.comment_text}
                              </Text>
                            </Box>
                          </Group>
                        </Card>
                      ))
                    ) : (
                      <Card withBorder p="xl">
                        <Text ta="center" c="dimmed">No comments yet</Text>
                      </Card>
                    )}
                  </Stack>
                </Stack>
              </Tabs.Panel>

              <Tabs.Panel value="attachments" pt="md">
                <Stack gap="md">
                  <Card withBorder p="md">
                    <FileInput
                      label="Upload File"
                      placeholder="Choose file to upload"
                      leftSection={<IconUpload size={16} />}
                      onChange={handleFileUpload}
                      disabled={uploadingFile}
                    />
                    {uploadingFile && (
                      <Text size="sm" c="dimmed" mt="xs">Uploading...</Text>
                    )}
                  </Card>

                  <Stack gap="sm">
                    {attachments.length > 0 ? (
                      attachments.map((attachment) => (
                        <Card key={attachment.attachment_id} withBorder p="md">
                          <Group justify="space-between">
                            <Group>
                              {isImage(attachment.file_type) ? (
                                <Image
                                  src={attachment.file_url}
                                  alt={attachment.file_name}
                                  w={40}
                                  h={40}
                                  fit="cover"
                                  radius="sm"
                                />
                              ) : (
                                <IconPaperclip size={20} />
                              )}
                              <Box>
                                <Anchor
                                  href={attachment.file_url}
                                  target="_blank"
                                  fw={500}
                                >
                                  {attachment.file_name}
                                </Anchor>
                                <Text size="xs" c="dimmed">
                                  {formatFileSize(attachment.file_size)} • 
                                  Uploaded by {attachment.uploaded_by_name} • 
                                  {new Date(attachment.created_at).toLocaleDateString()}
                                </Text>
                              </Box>
                            </Group>
                            <Group>
                              <ActionIcon
                                component="a"
                                href={attachment.file_url}
                                target="_blank"
                                variant="light"
                              >
                                <IconDownload size={16} />
                              </ActionIcon>
                              <ActionIcon
                                color="red"
                                variant="light"
                                onClick={() => handleDeleteAttachment(attachment.attachment_id)}
                              >
                                <IconTrash size={16} />
                              </ActionIcon>
                            </Group>
                          </Group>
                        </Card>
                      ))
                    ) : (
                      <Card withBorder p="xl">
                        <Text ta="center" c="dimmed">No files attached</Text>
                      </Card>
                    )}
                  </Stack>
                </Stack>
              </Tabs.Panel>

              <Tabs.Panel value="assignment" pt="md">
                <Stack gap="md">
                  <Card withBorder p="md">
                    <Stack gap="sm">
                      <Text fw={500}>Current Assignment</Text>
                      {task.assigned_crew_member ? (
                        <Group>
                          <Avatar size="sm" radius="xl">
                            {task.assigned_crew_member.user_name.charAt(0).toUpperCase()}
                          </Avatar>
                          <Box>
                            <Text fw={500}>{task.assigned_crew_member.user_name}</Text>
                            <Text size="sm" c="dimmed">
                              {task.assigned_crew_member.role_name} • {task.assigned_crew_member.department_name}
                            </Text>
                          </Box>
                        </Group>
                      ) : (
                        <Text c="dimmed">Not assigned</Text>
                      )}
                    </Stack>
                  </Card>

                  <Card withBorder p="md">
                    <Stack gap="sm">
                      <Text fw={500}>Assign to Crew Member</Text>
                      <Select
                        placeholder="Select crew member"
                        data={projectCrew.map(member => ({
                          value: member.project_crew_id,
                          label: `${member.user_name} (${member.role_name})`
                        }))}
                        onChange={(value) => value && handleAssignToCrew(value)}
                      />
                    </Stack>
                  </Card>

                  <Card withBorder p="md">
                    <Stack gap="sm">
                      <Text fw={500}>Available Crew Members</Text>
                      <Stack gap="xs">
                        {projectCrew.length > 0 ? (
                          projectCrew.map((member) => (
                            <Group key={member.project_crew_id} justify="space-between">
                              <Group>
                                <Avatar size="sm" radius="xl">
                                  {member.user_name.charAt(0).toUpperCase()}
                                </Avatar>
                                <Box>
                                  <Text size="sm" fw={500}>{member.user_name}</Text>
                                  <Text size="xs" c="dimmed">
                                    {member.role_name} • {member.department_name}
                                  </Text>
                                </Box>
                              </Group>
                              <Button
                                size="xs"
                                variant="light"
                                onClick={() => handleAssignToCrew(member.project_crew_id)}
                                disabled={task.assigned_project_crew_id === member.project_crew_id}
                              >
                                {task.assigned_project_crew_id === member.project_crew_id ? 'Assigned' : 'Assign'}
                              </Button>
                            </Group>
                          ))
                        ) : (
                          <Text c="dimmed" ta="center">No crew members available</Text>
                        )}
                      </Stack>
                    </Stack>
                  </Card>
                </Stack>
              </Tabs.Panel>
            </Tabs>
          </Stack>
        </Box>
      </Modal>

      {/* Edit Task Modal */}
      <Modal
        opened={editModalOpened}
        onClose={closeEditModal}
        title="Edit Task"
        size="lg"
      >
        <form onSubmit={editForm.onSubmit(handleUpdateTask)}>
          <Stack gap="md">
            <TextInput
              label="Task Name"
              required
              {...editForm.getInputProps('task_name')}
            />
            
            <Textarea
              label="Description"
              minRows={3}
              {...editForm.getInputProps('task_description')}
            />
            
            <NumberInput
              label="Estimated Hours"
              min={0}
              {...editForm.getInputProps('estimated_hours')}
            />

            {/* Checklist Items */}
            <Box>
              <Text size="sm" fw={500} mb="xs">Checklist Items</Text>
              <Stack gap="xs">
                {editForm.values.checklist_items.map((item, index) => (
                  <Group key={index}>
                    <Checkbox
                      checked={item.completed}
                      onChange={(e) => {
                        const items = [...editForm.values.checklist_items];
                        items[index].completed = e.currentTarget.checked;
                        editForm.setFieldValue('checklist_items', items);
                      }}
                    />
                    <TextInput
                      style={{ flex: 1 }}
                      value={item.text}
                      onChange={(e) => {
                        const items = [...editForm.values.checklist_items];
                        items[index].text = e.target.value;
                        editForm.setFieldValue('checklist_items', items);
                      }}
                    />
                    <ActionIcon
                      color="red"
                      variant="light"
                      onClick={() => {
                        const items = editForm.values.checklist_items.filter((_, i) => i !== index);
                        editForm.setFieldValue('checklist_items', items);
                      }}
                    >
                      <IconTrash size={16} />
                    </ActionIcon>
                  </Group>
                ))}
                <Button
                  variant="light"
                  size="xs"
                  leftSection={<IconPlus size={12} />}
                  onClick={() => {
                    const items = [...editForm.values.checklist_items, { text: '', completed: false }];
                    editForm.setFieldValue('checklist_items', items);
                  }}
                >
                  Add Checklist Item
                </Button>
              </Stack>
            </Box>

            <Group justify="flex-end">
              <Button variant="light" onClick={closeEditModal}>
                Cancel
              </Button>
              <Button type="submit">
                Update Task
              </Button>
            </Group>
          </Stack>
        </form>
      </Modal>
    </>
  );
}
