import { useState } from 'react';
import {
  Card,
  Grid,
  Text,
  Badge,
  Group,
  ActionIcon,
  Menu,
  Image,
  Progress,
  Stack,
  Box,
  TextInput,
  Select,
  Button,
  Pagination,
  LoadingOverlay,
  Alert,
  Flex
} from '@mantine/core';
import {
  IconSearch,
  IconFilter,
  IconDots,
  IconEdit,
  IconArchive,
  IconUsers,
  IconCalendar,
  IconAlertTriangle,
  IconEye,
  IconPlus
} from '@tabler/icons-react';
import { useProjects } from './project.hook';
import type { ProjectWithStats, ProjectFilters } from './project.typs';

interface ProjectListComponentProps {
  onCreateProject: () => void;
  onViewProject: (projectId: string) => void;
  onEditProject: (project: ProjectWithStats) => void;
  onAssignCrew: (projectId: string) => void;
  currentUserId: string;
}

export default function ProjectListComponent({
  onCreateProject,
  onViewProject,
  onEditProject,
  onAssignCrew
}: ProjectListComponentProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');

  const {
    projects,
    totalCount,
    currentPage,
    totalPages,
    loading,
    error,
    archiveProject,
    updateFilters,
    updatePagination
  } = useProjects();

  const handleSearch = () => {
    const filters: Partial<ProjectFilters> = {};
    if (searchTerm.trim()) {
      filters.search = searchTerm.trim();
    }
    if (statusFilter) {
      filters.project_status = statusFilter as 'active' | 'completed' | 'archived';
    }
    updateFilters(filters);
  };

  const handleClearFilters = () => {
    setSearchTerm('');
    setStatusFilter('');
    updateFilters({});
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'blue';
      case 'completed':
        return 'green';
      case 'archived':
        return 'gray';
      default:
        return 'gray';
    }
  };

  const getProgressPercentage = (project: ProjectWithStats) => {
    if (project.total_tasks === 0) return 0;
    return Math.round((project.completed_tasks / project.total_tasks) * 100);
  };

  const ProjectCard = ({ project }: { project: ProjectWithStats }) => (
    <Card shadow="sm" padding="lg" radius="md" withBorder>
      <Card.Section>
        {project.image_url ? (
          <Image
            src={project.image_url}
            height={160}
            alt={project.project_name}
            fallbackSrc="https://placehold.co/400x160?text=Project"
          />
        ) : (
          <Box
            h={160}
            bg="gray.1"
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <Text c="dimmed" size="sm">
              No image
            </Text>
          </Box>
        )}
      </Card.Section>

      <Stack gap="sm" mt="md">
        <Group justify="space-between">
          <Text fw={600} size="lg" lineClamp={1}>
            {project.project_name}
          </Text>
          <Menu shadow="md" width={200}>
            <Menu.Target>
              <ActionIcon variant="subtle" color="gray">
                <IconDots size={16} />
              </ActionIcon>
            </Menu.Target>
            <Menu.Dropdown>
              <Menu.Item
                leftSection={<IconEye size={14} />}
                onClick={() => onViewProject(project.project_id)}
              >
                View Details
              </Menu.Item>
              <Menu.Item
                leftSection={<IconEdit size={14} />}
                onClick={() => onEditProject(project)}
              >
                Edit Project
              </Menu.Item>
              <Menu.Item
                leftSection={<IconUsers size={14} />}
                onClick={() => onAssignCrew(project.project_id)}
              >
                Assign Crew
              </Menu.Item>
              <Menu.Divider />
              <Menu.Item
                leftSection={<IconArchive size={14} />}
                color="orange"
                onClick={() => archiveProject(project.project_id)}
              >
                Archive
              </Menu.Item>
            </Menu.Dropdown>
          </Menu>
        </Group>

        <Badge color={getStatusColor(project.project_status)} size="sm">
          {project.project_status.charAt(0).toUpperCase() + project.project_status.slice(1)}
        </Badge>

        {project.project_description && (
          <Text size="sm" c="dimmed" lineClamp={2}>
            {project.project_description}
          </Text>
        )}

        <Group gap="xs">
          <IconCalendar size={14} />
          <Text size="xs" c="dimmed">
            {project.project_start_date
              ? new Date(project.project_start_date).toLocaleDateString()
              : 'No start date'}
          </Text>
        </Group>

        {/* Progress */}
        <Box>
          <Group justify="space-between" mb={5}>
            <Text size="sm" fw={500}>
              Progress
            </Text>
            <Text size="sm" c="dimmed">
              {project.completed_tasks}/{project.total_tasks} tasks
            </Text>
          </Group>
          <Progress value={getProgressPercentage(project)} size="sm" />
        </Box>

        {/* Stats */}
        <Grid>
          <Grid.Col span={6}>
            <Group gap={4}>
              <IconUsers size={14} />
              <Text size="xs" c="dimmed">
                {project.assigned_roles}/{project.assigned_roles + project.unassigned_roles} roles filled
              </Text>
            </Group>
          </Grid.Col>
          <Grid.Col span={6}>
            {project.escalated_tasks > 0 && (
              <Group gap={4}>
                <IconAlertTriangle size={14} color="red" />
                <Text size="xs" c="red">
                  {project.escalated_tasks} escalated
                </Text>
              </Group>
            )}
          </Grid.Col>
        </Grid>

        <Group justify="space-between" mt="md">
          <Button
            variant="light"
            size="sm"
            leftSection={<IconEye size={14} />}
            onClick={() => onViewProject(project.project_id)}
          >
            View
          </Button>
          {project.unassigned_roles > 0 && (
            <Button
              variant="outline"
              size="sm"
              color="orange"
              leftSection={<IconUsers size={14} />}
              onClick={() => onAssignCrew(project.project_id)}
            >
              Assign Crew
            </Button>
          )}
        </Group>
      </Stack>
    </Card>
  );

  if (error) {
    return (
      <Alert color="red" title="Error loading projects">
        {error}
      </Alert>
    );
  }

  return (
    <Stack gap="md">
      {/* Header */}
      <Group justify="space-between">
        <Box>
          <Text size="xl" fw={600}>
            Projects
          </Text>
          <Text size="sm" c="dimmed">
            {totalCount} projects total
          </Text>
        </Box>
        <Button leftSection={<IconPlus size={16} />} onClick={onCreateProject}>
          New Project
        </Button>
      </Group>

      {/* Filters */}
      <Card withBorder p="md">
        <Grid align="end">
          <Grid.Col span={{ base: 12, sm: 6, md: 4 }}>
            <TextInput
              placeholder="Search projects..."
              leftSection={<IconSearch size={16} />}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            />
          </Grid.Col>
          <Grid.Col span={{ base: 12, sm: 6, md: 3 }}>
            <Select
              placeholder="Filter by status"
              leftSection={<IconFilter size={16} />}
              value={statusFilter}
              onChange={(value) => setStatusFilter(value || '')}
              data={[
                { value: 'active', label: 'Active' },
                { value: 'completed', label: 'Completed' },
                { value: 'archived', label: 'Archived' }
              ]}
              clearable
            />
          </Grid.Col>
          <Grid.Col span={{ base: 12, sm: 6, md: 2 }}>
            <Button onClick={handleSearch} fullWidth>
              Search
            </Button>
          </Grid.Col>
          <Grid.Col span={{ base: 12, sm: 6, md: 2 }}>
            <Button variant="light" onClick={handleClearFilters} fullWidth>
              Clear
            </Button>
          </Grid.Col>
        </Grid>
      </Card>

      {/* Projects Grid */}
      <Box pos="relative">
        <LoadingOverlay visible={loading} />
        
        {projects.length === 0 && !loading ? (
          <Card withBorder p="xl">
            <Stack align="center" gap="md">
              <Text size="lg" c="dimmed">
                No projects found
              </Text>
              <Button leftSection={<IconPlus size={16} />} onClick={onCreateProject}>
                Create your first project
              </Button>
            </Stack>
          </Card>
        ) : (
          <Grid>
            {projects.map((project) => (
              <Grid.Col key={project.project_id} span={{ base: 12, sm: 6, lg: 4 }}>
                <ProjectCard project={project} />
              </Grid.Col>
            ))}
          </Grid>
        )}
      </Box>

      {/* Pagination */}
      {totalPages > 1 && (
        <Flex justify="center" mt="md">
          <Pagination
            value={currentPage}
            onChange={(page) => updatePagination({ page })}
            total={totalPages}
            size="sm"
          />
        </Flex>
      )}
    </Stack>
  );
}
