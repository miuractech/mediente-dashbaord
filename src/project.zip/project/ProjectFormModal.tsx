import { useEffect, useState } from 'react';
import {
  Modal,
  Stack,
  TextInput,
  Textarea,
  Select,
  Button,
  Group,
  FileInput,
  Image,
  Box,
  Text,
  Card,
  Badge,
  LoadingOverlay,
  Alert
} from '@mantine/core';
import { DateInput } from '@mantine/dates';
import { useForm } from '@mantine/form';
import { notifications } from '@mantine/notifications';
import {
  IconCalendar,
  IconPhoto,
  IconTemplate,
  IconUsers,
  IconClock
} from '@tabler/icons-react';
import { projectTemplateService } from '../template/projectTemplateService';
import type { ProjectTemplate } from '../template/template.type';
import type { Project, CreateProjectRequest, UpdateProjectRequest } from './project.typs';
import { useProjects } from './project.hook';
import supabase from '../supabase';

interface ProjectFormModalProps {
  opened: boolean;
  onClose: () => void;
  onSuccess: () => void;
  project?: Project | null;
  currentUserId: string;
}

interface FormValues {
  project_name: string;
  project_description: string;
  template_id: string;
  project_start_date: Date | null;
  image_file: File | null;
}

export default function ProjectFormModal({
  opened,
  onClose,
  onSuccess,
  project,
  currentUserId
}: ProjectFormModalProps) {
  const [templates, setTemplates] = useState<ProjectTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<ProjectTemplate | null>(null);
  const [loadingTemplates, setLoadingTemplates] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const { createProject, updateProject } = useProjects();

  const isEditing = !!project;

  const form = useForm<FormValues>({
    initialValues: {
      project_name: '',
      project_description: '',
      template_id: '',
      project_start_date: null,
      image_file: null
    },
    validate: {
      project_name: (value) =>
        value.trim().length < 3 ? 'Project name must be at least 3 characters' : null,
      template_id: (value) =>
        !isEditing && !value ? 'Please select a template' : null
    }
  });

  // Load templates
  useEffect(() => {
    if (opened && !isEditing) {
      loadTemplates();
    }
  }, [opened, isEditing]);

  // Set form values when editing
  useEffect(() => {
    if (project && opened) {
      form.setValues({
        project_name: project.project_name,
        project_description: project.project_description || '',
        template_id: project.template_id,
        project_start_date: project.project_start_date ? new Date(project.project_start_date) : null,
        image_file: null
      });
      setImagePreview(project.image_url || null);
    }
  }, [project, opened, form]);

  const loadTemplates = async () => {
    try {
      setLoadingTemplates(true);
      const data = await projectTemplateService.getAll();
      setTemplates(data);
    } catch {
      notifications.show({
        title: 'Error',
        message: 'Failed to load templates',
        color: 'red'
      });
    } finally {
      setLoadingTemplates(false);
    }
  };

  const handleTemplateSelect = (templateId: string | null) => {
    if (!templateId) return;
    const template = templates.find(t => t.template_id === templateId);
    setSelectedTemplate(template || null);
    form.setFieldValue('template_id', templateId);
  };

  const handleImageChange = (file: File | null) => {
    form.setFieldValue('image_file', file);
    
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setImagePreview(null);
    }
  };

  const uploadImage = async (file: File): Promise<string> => {
    try {
      // Upload to Supabase Storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `project-images/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('projects')
        .upload(filePath, file);

      if (uploadError) {
        throw uploadError;
      }

      // Get public URL
      const { data } = supabase.storage
        .from('projects')
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      console.error('Error uploading image:', error);
      throw new Error('Failed to upload image');
    }
  };

  const handleSubmit = async (values: FormValues) => {
    try {
      setSubmitting(true);

      let imageUrl = project?.image_url || null;
      
      // Upload image if provided
      if (values.image_file) {
        imageUrl = await uploadImage(values.image_file);
      }

      if (isEditing && project) {
        // Update existing project
        const updateData: UpdateProjectRequest = {
          project_name: values.project_name,
          project_description: values.project_description || undefined,
          project_start_date: values.project_start_date instanceof Date ? values.project_start_date.toISOString().split('T')[0] : undefined
        };

        await updateProject(project.project_id, updateData, currentUserId);
      } else {
        // Create new project
        const createData: CreateProjectRequest = {
          project_name: values.project_name,
          project_description: values.project_description || undefined,
          template_id: values.template_id,
          project_start_date: values.project_start_date instanceof Date ? values.project_start_date.toISOString().split('T')[0] : undefined
        };

        await createProject(createData, currentUserId, imageUrl || undefined);
      }

      onSuccess();
      handleClose();
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: error instanceof Error ? error.message : (isEditing ? 'Failed to update project' : 'Failed to create project'),
        color: 'red'
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleClose = () => {
    form.reset();
    setSelectedTemplate(null);
    setImagePreview(null);
    onClose();
  };

  return (
    <Modal
      opened={opened}
      onClose={handleClose}
      title={isEditing ? 'Edit Project' : 'Create New Project'}
      size="lg"
      centered
    >
      <Box pos="relative">
        <LoadingOverlay visible={submitting} />
        
        <form onSubmit={form.onSubmit(handleSubmit)}>
          <Stack gap="md">
            {/* Project Name */}
            <TextInput
              label="Project Name"
              placeholder="Enter project name"
              required
              {...form.getInputProps('project_name')}
            />

            {/* Project Description */}
            <Textarea
              label="Project Description"
              placeholder="Enter project description"
              minRows={3}
              {...form.getInputProps('project_description')}
            />

            {/* Template Selection (only for new projects) */}
            {!isEditing && (
              <Box>
                <Text size="sm" fw={500} mb="xs">
                  Template *
                </Text>
                {loadingTemplates ? (
                  <Card withBorder p="md">
                    <Text c="dimmed" ta="center">Loading templates...</Text>
                  </Card>
                ) : (
                  <Select
                    placeholder="Select a project template"
                    data={templates.map(t => ({
                      value: t.template_id,
                      label: t.template_name
                    }))}
                    searchable
                    leftSection={<IconTemplate size={16} />}
                    {...form.getInputProps('template_id')}
                    onChange={handleTemplateSelect}
                  />
                )}

                {selectedTemplate && (
                  <Card withBorder mt="sm" p="md">
                    <Stack gap="xs">
                      <Group justify="space-between">
                        <Text fw={500}>{selectedTemplate.template_name}</Text>
                        <Badge size="sm" color="blue">Template</Badge>
                      </Group>
                      {selectedTemplate.description && (
                        <Text size="sm" c="dimmed">
                          {selectedTemplate.description}
                        </Text>
                      )}
                      <Group gap="md" mt="xs">
                        <Group gap={4}>
                          <IconUsers size={14} />
                          <Text size="xs" c="dimmed">Multiple roles</Text>
                        </Group>
                        <Group gap={4}>
                          <IconClock size={14} />
                          <Text size="xs" c="dimmed">Estimated timeline</Text>
                        </Group>
                      </Group>
                    </Stack>
                  </Card>
                )}
              </Box>
            )}

            {/* Start Date */}
            <DateInput
              label="Start Date"
              placeholder="Select project start date"
              leftSection={<IconCalendar size={16} />}
              {...form.getInputProps('project_start_date')}
            />

            {/* Project Image */}
            <Box>
              <Text size="sm" fw={500} mb="xs">
                Project Image
              </Text>
              <FileInput
                placeholder="Choose project image"
                accept="image/*"
                leftSection={<IconPhoto size={16} />}
                onChange={handleImageChange}
              />
              {imagePreview && (
                <Box mt="sm">
                  <Image
                    src={imagePreview}
                    alt="Project preview"
                    h={120}
                    w="auto"
                    fit="cover"
                    radius="md"
                  />
                </Box>
              )}
            </Box>

            {/* Info Alert for new projects */}
            {!isEditing && (
              <Alert color="blue" variant="light">
                <Text size="sm">
                  After creating the project, you'll need to assign crew members to roles before tasks can be started.
                </Text>
              </Alert>
            )}

            {/* Actions */}
            <Group justify="flex-end" mt="md">
              <Button variant="light" onClick={handleClose}>
                Cancel
              </Button>
              <Button type="submit" loading={submitting}>
                {isEditing ? 'Update Project' : 'Create Project'}
              </Button>
            </Group>
          </Stack>
        </form>
      </Box>
    </Modal>
  );
}