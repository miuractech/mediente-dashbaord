import supabase from '../supabase';
import type {
  Project,
  ProjectWithStats,
  ProjectRole,
  ProjectCrew,
  ProjectCrewWithUser,
  ProjectTask,
  ProjectTaskWithCrew,
  CreateProjectRequest,
  UpdateProjectRequest,
  AddCrewMemberRequest,
  UpdateCrewMemberRequest,
  AssignTaskToCrewRequest,
  UpdateProjectTaskRequest,
  ProjectFilters,
  ProjectTaskFilters,
  ProjectRoleFilters,
  ProjectCrewFilters,
  PaginationParams,
  PaginatedResponse,
  TaskComment,
  TaskAttachment,
  CreateTaskCommentRequest,
  CreateTaskAttachmentRequest
} from './project.typs';

// Project CRUD Operations
export const projectService = {
  // Create a new project
  async create(data: CreateProjectRequest, userId: string, imageUrl?: string): Promise<Project> {
    // First, get the template snapshot
    const { data: templateData, error: templateError } = await supabase
      .from('project_templates')
      .select(`
        *,
        template_phases (
          *,
          phase_steps (
            *,
            step_tasks (*)
          )
        )
      `)
      .eq('template_id', data.template_id)
      .eq('is_archived', false)
      .single();

    if (templateError) throw templateError;
    if (!templateData) throw new Error('Template not found');

    // Create project with template snapshot
    const { data: project, error } = await supabase
      .from('projects')
      .insert({
        project_name: data.project_name,
        project_description: data.project_description,
        template_id: data.template_id,
        project_start_date: data.project_start_date,
        image_url: imageUrl,
        template_snapshot: templateData,
        created_by: userId
      })
      .select()
      .single();

    if (error) throw error;
    if (!project) throw new Error('Failed to create project');

    // Create project roles from template
    await this.createProjectRolesFromTemplate(project.project_id, templateData, userId);

    // Create project tasks from template
    await this.createProjectTasksFromTemplate(project.project_id, templateData, userId);

    return project;
  },

  // Get projects with pagination and filters
  async getPaginated(
    pagination: PaginationParams = {},
    filters: ProjectFilters = {}
  ): Promise<PaginatedResponse<ProjectWithStats>> {
    const { page = 1, pageSize = 20 } = pagination;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase
      .from('projects_with_stats')
      .select('*', { count: 'exact' });

    // Apply filters
    if (filters.is_archived !== undefined) {
      query = query.eq('is_archived', filters.is_archived);
    } else {
      query = query.eq('is_archived', false);
    }

    if (filters.search) {
      query = query.or(`project_name.ilike.%${filters.search}%,project_description.ilike.%${filters.search}%`);
    }

    if (filters.project_status) {
      query = query.eq('project_status', filters.project_status);
    }

    if (filters.template_id) {
      query = query.eq('template_id', filters.template_id);
    }

    if (filters.created_by) {
      query = query.eq('created_by', filters.created_by);
    }

    if (filters.start_date_from) {
      query = query.gte('project_start_date', filters.start_date_from);
    }

    if (filters.start_date_to) {
      query = query.lte('project_start_date', filters.start_date_to);
    }

    const { data, error, count } = await query
      .order('created_at', { ascending: false })
      .range(from, to);

    if (error) throw error;

    return {
      data: data || [],
      count: count || 0,
      page,
      pageSize,
      totalPages: Math.ceil((count || 0) / pageSize)
    };
  },

  // Get project by ID
  async getById(projectId: string): Promise<ProjectWithStats | null> {
    const { data, error } = await supabase
      .from('projects_with_stats')
      .select('*')
      .eq('project_id', projectId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null;
      throw error;
    }

    return data;
  },

  // Update project
  async update(projectId: string, data: UpdateProjectRequest, _userId: string): Promise<Project> { // eslint-disable-line @typescript-eslint/no-unused-vars
    const { data: project, error } = await supabase
      .from('projects')
      .update({
        ...data,
        updated_at: new Date().toISOString()
      })
      .eq('project_id', projectId)
      .select()
      .single();

    if (error) throw error;
    return project;
  },

  // Archive project
  async archive(projectId: string): Promise<void> {
    const { error } = await supabase
      .from('projects')
      .update({ 
        is_archived: true,
        project_status: 'archived',
        updated_at: new Date().toISOString()
      })
      .eq('project_id', projectId);

    if (error) throw error;
  },

  // Delete project (hard delete)
  async delete(projectId: string): Promise<void> {
    const { error } = await supabase
      .from('projects')
      .delete()
      .eq('project_id', projectId);

    if (error) throw error;
  },

  // Check if all roles are filled
  async areAllRolesFilled(projectId: string): Promise<boolean> {
    const { data, error } = await supabase
      .rpc('are_all_roles_filled', { project_uuid: projectId });

    if (error) throw error;
    return data;
  },

  // Private helper methods
  async createProjectRolesFromTemplate(projectId: string, templateData: Record<string, unknown>, _userId: string): Promise<void> {
    const roles = new Set<string>();
    
    // Extract unique roles from template
    (templateData.template_phases as Array<Record<string, unknown>>)?.forEach((phase) => {
      (phase.phase_steps as Array<Record<string, unknown>>)?.forEach((step) => {
        (step.step_tasks as Array<Record<string, unknown>>)?.forEach((task) => {
          if (task.assigned_role_id) {
            roles.add(task.assigned_role_id as string);
          }
        });
      });
    });

    if (roles.size === 0) return;

    // Get role details
    const { data: roleDetails, error: roleError } = await supabase
      .from('department_roles')
      .select(`
        role_id,
        role_name,
        department_id,
        departments!inner(department_name)
      `)
      .in('role_id', Array.from(roles));

    if (roleError) throw roleError;

    // Create project roles
    const projectRoles = roleDetails?.map(role => ({
      project_id: projectId,
      role_id: role.role_id,
      role_name: role.role_name,
      department_id: role.department_id,
      department_name: (role.departments as { department_name: string }[])?.[0]?.department_name || '',
      required_count: 1, // Default to 1, can be customized later
      created_by: _userId
    })) || [];

    if (projectRoles.length > 0) {
      const { error } = await supabase
        .from('project_roles')
        .insert(projectRoles);

      if (error) throw error;
    }
  },

  async createProjectTasksFromTemplate(projectId: string, templateData: Record<string, unknown>, _userId: string): Promise<void> {
    const tasks: Array<Record<string, unknown>> = [];

    (templateData.template_phases as Array<Record<string, unknown>>)?.forEach((phase) => {
      (phase.phase_steps as Array<Record<string, unknown>>)?.forEach((step) => {
        (step.step_tasks as Array<Record<string, unknown>>)?.forEach((task) => {
          tasks.push({
            project_id: projectId,
            task_name: task.task_name,
            task_description: task.description,
            phase_name: phase.phase_name,
            phase_order: phase.phase_order,
            step_name: step.step_name,
            step_order: step.step_order,
            task_order: task.task_order,
            estimated_hours: task.estimated_hours,
            category: task.category,
            checklist_items: task.checklist_items || [],
            is_critical: false,
            created_by: _userId
          });
        });
      });
    });

    if (tasks.length > 0) {
      const { error } = await supabase
        .from('project_tasks')
        .insert(tasks);

      if (error) throw error;
    }
  }
};

// Project Roles Service
export const projectRoleService = {
  // Get project roles
  async getByProject(
    projectId: string,
    filters: ProjectRoleFilters = {}
  ): Promise<ProjectRole[]> {
    let query = supabase
      .from('project_roles')
      .select('*')
      .eq('project_id', projectId);

    if (filters.role_id) {
      query = query.eq('role_id', filters.role_id);
    }

    if (filters.department_id) {
      query = query.eq('department_id', filters.department_id);
    }

    if (filters.is_active !== undefined) {
      query = query.eq('is_active', filters.is_active);
    }

    if (filters.search) {
      query = query.or(`role_name.ilike.%${filters.search}%,department_name.ilike.%${filters.search}%`);
    }

    const { data, error } = await query.order('department_name', { ascending: true });

    if (error) throw error;
    return data || [];
  },

};

// Project Crew Service
export const projectCrewService = {
  // Get project crew members
  async getByProject(
    projectId: string,
    filters: ProjectCrewFilters = {}
  ): Promise<ProjectCrewWithUser[]> {
    let query = supabase
      .from('project_crew_with_user')
      .select('*')
      .eq('project_id', projectId);

    if (filters.role_id) {
      query = query.eq('role_id', filters.role_id);
    }

    if (filters.department_id) {
      query = query.eq('department_id', filters.department_id);
    }

    if (filters.user_id) {
      query = query.eq('user_id', filters.user_id);
    }


    if (filters.is_active !== undefined) {
      query = query.eq('is_active', filters.is_active);
    }

    const { data, error } = await query
      .order('department_name', { ascending: true })
      .order('role_name', { ascending: true });

    if (error) throw error;
    return data || [];
  },

  // Add crew member to project
  async addCrewMember(data: AddCrewMemberRequest, userId: string): Promise<ProjectCrew> {
    let crewUserId = data.user_id;

    // If no user_id provided, create new crew member
    if (!crewUserId && data.user_email) {
      const { data: newCrew, error: crewError } = await supabase
        .from('crew')
        .insert({
          name: data.user_name || data.user_email,
          email: data.user_email,
          phone: data.user_phone,
          created_by: userId
        })
        .select()
        .single();

      if (crewError) {
        if (crewError.code === '23505') { // Unique constraint violation
          throw new Error('Email already exists in the system');
        }
        throw new Error(crewError.message || 'Failed to create crew member');
      }
      crewUserId = newCrew.id;
    }

    if (!crewUserId) {
      throw new Error('Either user_id or user_email must be provided');
    }

    // Get role details
    const { data: roleData, error: roleError } = await supabase
      .from('department_roles')
      .select(`
        role_id,
        role_name,
        department_id,
        departments!inner(department_name)
      `)
      .eq('role_id', data.role_id)
      .single();

    if (roleError) throw roleError;

    // Check if role is already assigned to someone
    const { data: existingAssignment, error: checkError } = await supabase
      .from('project_crew')
      .select('project_crew_id')
      .eq('project_id', data.project_id)
      .eq('role_id', data.role_id)
      .eq('is_active', true)
      .single();

    if (checkError && checkError.code !== 'PGRST116') throw checkError;
    if (existingAssignment) {
      throw new Error('This role is already assigned to another crew member');
    }

    // Add to project crew
    const { data: projectCrew, error } = await supabase
      .from('project_crew')
      .insert({
        project_id: data.project_id,
        user_id: crewUserId,
        role_id: data.role_id,
        role_name: roleData.role_name,
        department_id: roleData.department_id,
        department_name: (roleData.departments as { department_name: string }[])?.[0]?.department_name || '',
        notes: data.notes,
        created_by: userId
      })
      .select()
      .single();

    if (error) throw error;
    return projectCrew;
  },

  // Update crew member
  async updateCrewMember(data: UpdateCrewMemberRequest, userId: string): Promise<ProjectCrew> {
    const { data: projectCrew, error } = await supabase
      .from('project_crew')
      .update({
        notes: data.notes,
        updated_by: userId,
        updated_at: new Date().toISOString()
      })
      .eq('project_crew_id', data.project_crew_id)
      .select()
      .single();

    if (error) throw error;
    return projectCrew;
  },

  // Remove crew member from project
  async removeCrewMember(projectCrewId: string): Promise<void> {
    const { error } = await supabase
      .from('project_crew')
      .update({
        is_active: false,
        left_date: new Date().toISOString().split('T')[0],
        updated_at: new Date().toISOString()
      })
      .eq('project_crew_id', projectCrewId);

    if (error) throw error;
  }
};

// Project Tasks Service
export const projectTaskService = {
  // Get project tasks
  async getByProject(
    projectId: string,
    filters: ProjectTaskFilters = {},
    pagination: PaginationParams = {}
  ): Promise<PaginatedResponse<ProjectTaskWithCrew>> {
    const { page = 1, pageSize = 50 } = pagination;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase
      .from('project_tasks_with_crew')
      .select('*', { count: 'exact' })
      .eq('project_id', projectId);

    // Apply filters
    if (filters.is_archived !== undefined) {
      query = query.eq('is_archived', filters.is_archived);
    } else {
      query = query.eq('is_archived', false);
    }

    if (filters.search) {
      query = query.or(`task_name.ilike.%${filters.search}%,task_description.ilike.%${filters.search}%`);
    }

    if (filters.task_status) {
      query = query.eq('task_status', filters.task_status);
    }

    if (filters.assigned_crew_id) {
      query = query.eq('assigned_project_crew_id', filters.assigned_crew_id);
    }

    if (filters.assigned_role_id) {
      query = query.eq('assigned_project_role_id', filters.assigned_role_id);
    }

    if (filters.category) {
      query = query.eq('category', filters.category);
    }

    if (filters.phase_name) {
      query = query.eq('phase_name', filters.phase_name);
    }

    const { data, error, count } = await query
      .order('phase_order', { ascending: true })
      .order('step_order', { ascending: true })
      .order('task_order', { ascending: true })
      .range(from, to);

    if (error) throw error;

    return {
      data: data || [],
      count: count || 0,
      page,
      pageSize,
      totalPages: Math.ceil((count || 0) / pageSize)
    };
  },

  // Assign task to crew member
  async assignToCrew(data: AssignTaskToCrewRequest, userId: string): Promise<ProjectTask> {
    const { data: task, error } = await supabase
      .from('project_tasks')
      .update({
        assigned_project_crew_id: data.project_crew_id,
        updated_by: userId,
        updated_at: new Date().toISOString()
      })
      .eq('project_task_id', data.project_task_id)
      .select()
      .single();

    if (error) throw error;
    return task;
  },

  // Start task
  async startTask(projectTaskId: string, userId: string): Promise<ProjectTask> {
    const { data: task, error } = await supabase
      .from('project_tasks')
      .update({
        task_status: 'ongoing',
        updated_by: userId,
        updated_at: new Date().toISOString()
      })
      .eq('project_task_id', projectTaskId)
      .select()
      .single();

    if (error) throw error;
    return task;
  },

  // Complete task
  async completeTask(projectTaskId: string, userId: string): Promise<ProjectTask> {
    const { data: task, error } = await supabase
      .from('project_tasks')
      .update({
        task_status: 'completed',
        updated_by: userId,
        updated_at: new Date().toISOString()
      })
      .eq('project_task_id', projectTaskId)
      .select()
      .single();

    if (error) throw error;
    return task;
  },

  // Update task
  async updateTask(
    projectTaskId: string, 
    data: UpdateProjectTaskRequest, 
    userId: string
  ): Promise<ProjectTask> {
    const { data: task, error } = await supabase
      .from('project_tasks')
      .update({
        ...data,
        updated_by: userId,
        updated_at: new Date().toISOString()
      })
      .eq('project_task_id', projectTaskId)
      .select()
      .single();

    if (error) throw error;
    return task;
  },

  // Get tasks assigned to a specific crew member
  async getTasksByCrewMember(userId: string): Promise<ProjectTaskWithCrew[]> {
    const { data, error } = await supabase
      .from('project_tasks_with_crew')
      .select('*')
      .eq('assigned_user_id', userId)
      .eq('is_archived', false)
      .in('task_status', ['pending', 'ongoing', 'escalated'])
      .order('expected_end_time', { ascending: true, nullsFirst: false });

    if (error) throw error;
    return data || [];
  }
};

// Task Comments Service
export const taskCommentService = {
  // Get comments for a task
  async getByTask(projectTaskId: string): Promise<TaskComment[]> {
    const { data, error } = await supabase
      .from('task_comments_with_user')
      .select('*')
      .eq('project_task_id', projectTaskId)
      .order('created_at', { ascending: true });

    if (error) throw error;
    return data || [];
  },

  // Add comment to task
  async create(data: CreateTaskCommentRequest, userId: string): Promise<TaskComment> {
    const { data: comment, error } = await supabase
      .from('task_comments')
      .insert({
        project_task_id: data.project_task_id,
        comment_text: data.comment_text,
        author_id: userId,
        created_at: new Date().toISOString()
      })
      .select(`
        *,
        author:crew!author_id(name, email)
      `)
      .single();

    if (error) throw error;
    return {
      comment_id: comment.comment_id,
      project_task_id: comment.project_task_id,
      comment_text: comment.comment_text,
      author_id: comment.author_id,
      author_name: comment.author?.name || 'Unknown User',
      author_email: comment.author?.email || '',
      created_at: comment.created_at,
      updated_at: comment.updated_at
    };
  },

  // Delete comment
  async delete(commentId: string): Promise<void> {
    const { error } = await supabase
      .from('task_comments')
      .delete()
      .eq('comment_id', commentId);

    if (error) throw error;
  }
};

// Task Attachments Service
export const taskAttachmentService = {
  // Get attachments for a task
  async getByTask(projectTaskId: string): Promise<TaskAttachment[]> {
    const { data, error } = await supabase
      .from('task_attachments_with_user')
      .select('*')
      .eq('project_task_id', projectTaskId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  // Upload file and create attachment
  async create(data: CreateTaskAttachmentRequest, userId: string): Promise<TaskAttachment> {
    const { data: attachment, error } = await supabase
      .from('task_attachments')
      .insert({
        project_task_id: data.project_task_id,
        file_name: data.file_name,
        file_url: data.file_url,
        file_type: data.file_type,
        file_size: data.file_size,
        uploaded_by: userId,
        created_at: new Date().toISOString()
      })
      .select(`
        *,
        uploader:crew!uploaded_by(name, email)
      `)
      .single();

    if (error) throw error;
    return {
      attachment_id: attachment.attachment_id,
      project_task_id: attachment.project_task_id,
      file_name: attachment.file_name,
      file_url: attachment.file_url,
      file_type: attachment.file_type,
      file_size: attachment.file_size,
      uploaded_by: attachment.uploaded_by,
      uploaded_by_name: attachment.uploader?.name || 'Unknown User',
      created_at: attachment.created_at
    };
  },

  // Delete attachment
  async delete(attachmentId: string): Promise<void> {
    const { error } = await supabase
      .from('task_attachments')
      .delete()
      .eq('attachment_id', attachmentId);

    if (error) throw error;
  },

  // Upload file to Supabase storage
  async uploadFile(file: File, projectTaskId: string): Promise<string> {
    const fileExt = file.name.split('.').pop();
    const fileName = `${projectTaskId}/${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
    
    const { error: uploadError } = await supabase.storage
      .from('task-attachments')
      .upload(fileName, file);

    if (uploadError) throw uploadError;

    const { data } = supabase.storage
      .from('task-attachments')
      .getPublicUrl(fileName);

    return data.publicUrl;
  }
};
