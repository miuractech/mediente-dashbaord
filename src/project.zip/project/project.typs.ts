import type { TaskCategoryType } from "../template/template.type";

// Project status enum
export type ProjectStatusType =  'active' | 'completed' | 'archived';

// Task status enum (Jira-style)
export type TaskStatusType = 'pending' | 'ongoing' | 'completed' | 'escalated';

// Base project type
export interface Project {
  project_id: string; // auto generated from supabase table
  project_name: string; // from user    
  image_url: string | null; // from user
  project_description: string | null; // from user
  project_status: ProjectStatusType; // default to active
  project_start_date: string | null; // from user
  project_end_date?: string | null; // default to null
  template_id: string; // from template
  template_snapshot: Record<string, unknown>; // JSONB data - copy of all the tasks with steps and phases to populate the tasks in the project automatically
  is_archived: boolean; // default to false
  created_by: string; // automatically captured from current user
  created_at: string; // automatically captured from supabase table
}

// Project with statistics
export interface ProjectWithStats extends Project {
  total_tasks: number;
  completed_tasks: number;
  in_progress_tasks: number;
  pending_tasks: number;
  escalated_tasks: number;
  assigned_roles: number;
  unassigned_roles: number;
}

// Project role (updated for crew model)
export interface ProjectRole {
  project_role_id: string;
  project_id: string;
  role_id: string;
  role_name: string;
  department_id: string;
  department_name: string;
  required_count: number;
  filled_count: number;
  is_active: boolean;
  created_by: string;
  updated_by: string | null;
  created_at: string;
  updated_at: string;
}

// Project crew member
export interface ProjectCrew {
  project_crew_id: string;
  project_id: string;
  user_id: string;
  role_id: string;
  role_name: string;
  department_id: string;
  department_name: string;
  is_lead: boolean;
  is_active: boolean;
  joined_date: string | null;
  left_date: string | null;
  notes: string | null;
  created_by: string;
  updated_by: string | null;
  created_at: string;
  updated_at: string;
}

// Project crew member with user details
export interface ProjectCrewWithUser extends ProjectCrew {
  user_name: string;
  user_email: string;
  user_first_name?: string;
  user_last_name?: string;
  user_phone?: string;
  task_count: number;
  completed_task_count: number;
}

// Project role with crew details
export interface ProjectRoleWithCrew extends ProjectRole {
  crew_members: ProjectCrewWithUser[];
  task_count: number;
  completed_task_count: number;
}

// Legacy: Project role with user details (for backward compatibility)
export interface ProjectRoleWithUser extends ProjectRole {
  assigned_user_id?: string | null;
  assigned_user_name?: string;
  assigned_user_email?: string;
  task_count: number;
  completed_task_count: number;
}

// Project task (updated for crew model)
export interface ProjectTask {
  project_task_id: string;
  project_id: string;
  task_name: string;
  task_description: string | null;
  phase_name: string;
  phase_order: number;
  step_name: string;
  step_order: number;
  task_order: number;
  estimated_hours: number | null;
  actual_hours: number | null;
  assigned_project_role_id: string | null;
  assigned_project_crew_id: string | null;
  parent_task_id: string | null;
  task_status: TaskStatusType;
  category: TaskCategoryType | null;
  checklist_items: Array<{ text: string; completed: boolean }>;
  expected_start_time: string | null;
  expected_end_time: string | null;
  actual_start_time: string | null;
  actual_end_time: string | null;
  is_critical: boolean;
  escalation_reason: string | null;
  escalated_at: string | null;
  file_attachments: Array<{ name: string; url: string; type: string; size: number }>;
  comments: Array<{ text: string; author: string; created_at: string }>;
  started_at: string | null; // Legacy field
  completed_at: string | null; // Legacy field
  is_archived: boolean;
  created_by: string;
  updated_by: string | null;
  created_at: string;
  updated_at: string;
}

// Project task with crew and role details
export interface ProjectTaskWithCrew extends ProjectTask {
  assigned_crew_member?: ProjectCrewWithUser;
  assigned_role_name?: string;
  assigned_department_name?: string;
}

// Legacy interface for backwards compatibility
export interface ProjectTaskWithUser extends ProjectTask {
  assigned_user_name?: string;
  assigned_user_email?: string;
  assigned_role_name?: string;
  assigned_department_name?: string;
}

// Request types
export interface CreateProjectRequest {
  project_name: string;
  project_description?: string;
  template_id: string;
  project_start_date?: string;
}

export interface UpdateProjectRequest {
  project_name?: string;
  project_description?: string;
  project_status?: ProjectStatusType;
  project_start_date?: string;
  project_end_date?: string;
  is_archived?: boolean;
}

export interface AssignUserToRoleRequest {
  project_role_id: string;
  user_id: string;
}

// New crew management request types
export interface AddCrewMemberRequest {
  project_id: string;
  user_id?: string; // If user exists
  role_id: string;
  notes?: string;
  // For new users
  user_email?: string;
  user_name?: string;
  user_first_name?: string;
  user_last_name?: string;
  user_phone?: string;
}

export interface UpdateCrewMemberRequest {
  project_crew_id: string;
  notes?: string;
}

export interface AssignTaskToCrewRequest {
  project_task_id: string;
  project_crew_id: string;
}

export interface StartTaskCrewRequest {
  project_task_id: string;
  project_crew_id?: string;
}

export interface UpdateProjectTaskRequest {
  task_name?: string;
  task_description?: string;
  estimated_hours?: number;
  checklist_items?: Array<{ text: string; completed: boolean }>;
  file_attachments?: Array<{ name: string; url: string; type: string; size: number }>;
  comments?: Array<{ text: string; author: string; created_at: string }>;
}

// Task comment types
export interface TaskComment {
  comment_id: string;
  project_task_id: string;
  comment_text: string;
  author_id: string;
  author_name: string;
  author_email: string;
  created_at: string;
  updated_at: string;
}

export interface CreateTaskCommentRequest {
  project_task_id: string;
  comment_text: string;
}

// Task attachment types
export interface TaskAttachment {
  attachment_id: string;
  project_task_id: string;
  file_name: string;
  file_url: string;
  file_type: string;
  file_size: number;
  uploaded_by: string;
  uploaded_by_name: string;
  created_at: string;
}

export interface CreateTaskAttachmentRequest {
  project_task_id: string;
  file_name: string;
  file_url: string;
  file_type: string;
  file_size: number;
}

export interface StartTaskRequest {
  project_task_id: string;
  user_id?: string;
}

export interface CompleteTaskRequest {
  project_task_id: string;
}

// Filter types
export interface ProjectFilters {
  is_archived?: boolean;
  search?: string;
  project_status?: ProjectStatusType;
  template_id?: string;
  created_by?: string;
  start_date_from?: string;
  start_date_to?: string;
}

export interface ProjectTaskFilters {
  is_archived?: boolean;
  search?: string;
  task_status?: TaskStatusType;
  assigned_crew_id?: string | null;
  assigned_role_id?: string;
  category?: TaskCategoryType;
  phase_name?: string;
}

export interface ProjectRoleFilters {
  role_id?: string;
  department_id?: string;
  is_active?: boolean;
  search?: string;
}

export interface ProjectCrewFilters {
  role_id?: string;
  department_id?: string;
  user_id?: string;
  is_active?: boolean;
}

// Pagination types
export interface PaginationParams {
  page?: number;
  pageSize?: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  count: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

export type PaginatedProjectsResponse = PaginatedResponse<Project>;
export type PaginatedProjectTasksResponse = PaginatedResponse<ProjectTask>;
export type PaginatedProjectRolesResponse = PaginatedResponse<ProjectRole>;
export type PaginatedProjectCrewResponse = PaginatedResponse<ProjectCrew>;

// Re-export for backwards compatibility
export type ProjectType = Project;
