import { useEffect, useState, useCallback } from 'react';
import {
  Modal,
  Stack,
  Text,
  Card,
  Group,
  Badge,
  Button,
  Select,
  TextInput,
  Checkbox,
  ActionIcon,
  Avatar,
  Box,
  Alert,
  LoadingOverlay,
  Textarea
} from '@mantine/core';
import { useForm } from '@mantine/form';
import { notifications } from '@mantine/notifications';
import {
  IconUsers,
  IconPlus,
  IconUserCheck,
  IconUserX,
  IconMail,
  IconPhone
} from '@tabler/icons-react';
import { useProject, useProjectRoles, useProjectCrew } from './project.hook';
import { crewService } from '../crew/crew.service';
import type { ProjectRole, AddCrewMemberRequest } from './project.typs';
import type { crewType } from '../crew/crew.type';

interface ProjectCrewAssignmentModalProps {
  opened: boolean;
  onClose: () => void;
  projectId: string;
  currentUserId: string;
}

interface AddCrewForm {
  user_id: string;
  role_id: string;
  notes: string;
  // For new crew members
  user_email: string;
  user_name: string;
  user_phone: string;
}

export default function ProjectCrewAssignmentModal({
  opened,
  onClose,
  projectId,
  currentUserId
}: ProjectCrewAssignmentModalProps) {
  const [availableCrew, setAvailableCrew] = useState<crewType[]>([]);
  const [, setLoadingCrew] = useState(false);
  const [selectedRole, setSelectedRole] = useState<ProjectRole | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [addingNewUser, setAddingNewUser] = useState(false);

  const { project, loading: projectLoading } = useProject(projectId);
  const { roles, loading: rolesLoading } = useProjectRoles(projectId);
  const { crew, loading: crewLoading, addCrewMember, removeCrewMember } = useProjectCrew(projectId);

  const addCrewForm = useForm<AddCrewForm>({
    initialValues: {
      user_id: '',
      role_id: '',
      notes: '',
      user_email: '',
      user_name: '',
      user_phone: ''
    },
    validate: {
      role_id: (value) => !value ? 'Please select a role' : null,
      user_id: (value) => !addingNewUser && !value ? 'Please select a crew member' : null,
      user_email: (value) => addingNewUser && !value ? 'Email is required for new crew members' : null,
      user_name: (value) => addingNewUser && !value ? 'Name is required for new crew members' : null
    }
  });

  const loadAvailableCrew = useCallback(async () => {
    try {
      setLoadingCrew(true);
      const data = await crewService.getAllCrew();
      setAvailableCrew(data);
    } catch {
      notifications.show({
        title: 'Error',
        message: 'Failed to load crew members',
        color: 'red'
      });
    } finally {
      setLoadingCrew(false);
    }
  }, []);

  // Load available crew when modal opens
  useEffect(() => {
    if (opened) {
      loadAvailableCrew();
    }
  }, [opened, loadAvailableCrew]);

  const handleAddCrewMember = async (values: AddCrewForm) => {
    try {
      const request: AddCrewMemberRequest = {
        project_id: projectId,
        role_id: values.role_id,
        notes: values.notes || undefined
      };

      if (addingNewUser) {
        request.user_email = values.user_email;
        request.user_name = values.user_name;
        request.user_phone = values.user_phone || undefined;
      } else {
        request.user_id = values.user_id;
      }

      await addCrewMember(request, currentUserId);
      
      addCrewForm.reset();
      setShowAddForm(false);
      setAddingNewUser(false);
      setSelectedRole(null);
    } catch {
      // Error is handled in the hook
    }
  };

  const handleRemoveCrewMember = async (projectCrewId: string) => {
    try {
      await removeCrewMember(projectCrewId);
    } catch {
      // Error is handled in the hook
    }
  };

  const getUnassignedRoles = () => {
    const assignedRoleIds = crew.map(c => c.role_id);
    return roles.filter(role => !assignedRoleIds.includes(role.role_id));
  };

  const isRoleAssigned = (roleId: string) => {
    return crew.some(c => c.role_id === roleId);
  };

  const getAvailableCrewForRole = () => {
    const assignedUserIds = crew.map(c => c.user_id);
    return availableCrew.filter(c => !assignedUserIds.includes(c.id));
  };

  if (!project) {
    return null;
  }

  return (
    <Modal
      opened={opened}
      onClose={onClose}
      title={`Assign Crew - ${project.project_name}`}
      size="xl"
      centered
    >
      <Box pos="relative">
        <LoadingOverlay visible={projectLoading || rolesLoading} />

        <Stack gap="md">
          {/* Project Status */}
          <Alert color="blue" variant="light">
            <Group justify="space-between">
              <Text size="sm">
                {getUnassignedRoles().length === 0 
                  ? 'All roles are assigned! Tasks can now be started.'
                  : `${getUnassignedRoles().length} roles still need crew members.`
                }
              </Text>
              <Badge color={getUnassignedRoles().length === 0 ? 'green' : 'orange'}>
                {crew.length} crew members assigned
              </Badge>
            </Group>
          </Alert>

          {/* Roles Overview */}
          <Card withBorder>
            <Text fw={600} mb="md">Project Roles</Text>
            <Stack gap="sm">
              {roles.map((role) => (
                <Card key={role.project_role_id} withBorder p="sm">
                  <Group justify="space-between">
                    <Box>
                      <Text fw={500}>{role.role_name}</Text>
                      <Text size="sm" c="dimmed">{role.department_name}</Text>
                    </Box>
                    <Group gap="xs">
                      {isRoleAssigned(role.role_id) ? (
                        <Badge color="green" size="sm">
                          Assigned
                        </Badge>
                      ) : (
                        <Button
                          size="xs"
                          variant="light"
                          leftSection={<IconPlus size={12} />}
                          onClick={() => {
                            setSelectedRole(role);
                            addCrewForm.setFieldValue('role_id', role.role_id);
                            setShowAddForm(true);
                          }}
                        >
                          Assign Member
                        </Button>
                      )}
                    </Group>
                  </Group>
                </Card>
              ))}
            </Stack>
          </Card>

          {/* Add Crew Member Form */}
          {showAddForm && selectedRole && (
            <Card withBorder>
              <Text fw={600} mb="md">
                Add Crew Member to {selectedRole.role_name}
              </Text>
              
              <form onSubmit={addCrewForm.onSubmit(handleAddCrewMember)}>
                <Stack gap="md">
                  <Checkbox
                    label="Add new crew member (not in system yet)"
                    checked={addingNewUser}
                    onChange={(e) => {
                      setAddingNewUser(e.currentTarget.checked);
                      addCrewForm.reset();
                      addCrewForm.setFieldValue('role_id', selectedRole.role_id);
                    }}
                  />

                  {addingNewUser ? (
                    <>
                      <TextInput
                        label="Name"
                        placeholder="Enter crew member name"
                        required
                        {...addCrewForm.getInputProps('user_name')}
                      />
                      <TextInput
                        label="Email"
                        placeholder="Enter email address"
                        type="email"
                        required
                        leftSection={<IconMail size={16} />}
                        {...addCrewForm.getInputProps('user_email')}
                      />
                      <TextInput
                        label="Phone"
                        placeholder="Enter phone number"
                        leftSection={<IconPhone size={16} />}
                        {...addCrewForm.getInputProps('user_phone')}
                      />
                    </>
                  ) : (
                    <Select
                      label="Select Crew Member"
                      placeholder="Choose from existing crew"
                      required
                      searchable
                      data={getAvailableCrewForRole().map(c => ({
                        value: c.id,
                        label: `${c.name} (${c.email})`
                      }))}
                      leftSection={<IconUsers size={16} />}
                      {...addCrewForm.getInputProps('user_id')}
                    />
                  )}


                  <Textarea
                    label="Notes"
                    placeholder="Any additional notes about this assignment"
                    {...addCrewForm.getInputProps('notes')}
                  />

                  <Group justify="flex-end">
                    <Button 
                      variant="light" 
                      onClick={() => {
                        setShowAddForm(false);
                        setSelectedRole(null);
                        addCrewForm.reset();
                        setAddingNewUser(false);
                      }}
                    >
                      Cancel
                    </Button>
                    <Button type="submit" loading={crewLoading}>
                      Add Member
                    </Button>
                  </Group>
                </Stack>
              </form>
            </Card>
          )}

          {/* Current Crew Members */}
          <Card withBorder>
            <Group justify="space-between" mb="md">
              <Text fw={600}>Current Crew Members</Text>
              <Badge>{crew.length} members</Badge>
            </Group>

            {crew.length === 0 ? (
              <Text c="dimmed" ta="center" py="xl">
                No crew members assigned yet
              </Text>
            ) : (
              <Stack gap="sm">
                {crew.map((member) => (
                  <Card key={member.project_crew_id} withBorder p="sm">
                    <Group justify="space-between">
                      <Group>
                        <Avatar 
                          src={member.user_phone || undefined} 
                          size="sm"
                          name={member.user_name}
                        />
                        <Box>
                          <Text fw={500}>{member.user_name}</Text>
                          <Text size="sm" c="dimmed">{member.user_email}</Text>
                          <Text size="xs" c="dimmed">
                            {member.role_name} • {member.department_name}
                          </Text>
                          {member.notes && (
                            <Text size="xs" c="dimmed" fs="italic">
                              {member.notes}
                            </Text>
                          )}
                        </Box>
                      </Group>

                      <Group gap="xs">
                        <Text size="xs" c="dimmed">
                          {member.completed_task_count}/{member.task_count} tasks
                        </Text>
                        <ActionIcon
                          variant="subtle"
                          color="red"
                          size="sm"
                          onClick={() => handleRemoveCrewMember(member.project_crew_id)}
                        >
                          <IconUserX size={14} />
                        </ActionIcon>
                      </Group>
                    </Group>
                  </Card>
                ))}
              </Stack>
            )}
          </Card>

          {/* Actions */}
          <Group justify="flex-end">
            <Button variant="light" onClick={onClose}>
              Close
            </Button>
            {getUnassignedRoles().length === 0 && (
              <Button color="green" leftSection={<IconUserCheck size={16} />}>
                All Roles Assigned
              </Button>
            )}
          </Group>
        </Stack>
      </Box>
    </Modal>
  );
}
