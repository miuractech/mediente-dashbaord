# Project Module

The Project Module implements a complete project management system with roles and crew separation, following the specification provided.

## Overview

The project module consists of:
- **Projects**: Main project entities with template-based task creation
- **Project Roles**: Placeholder roles that need to be filled by crew members
- **Project Crew**: Real crew members assigned to specific roles
- **Project Tasks**: Tasks derived from templates with crew assignments and automatic escalation

## Key Features

### 1. Project Lifecycle
- **Create Project**: Select template, capture project details, auto-populate tasks and roles
- **Assign Crew**: Map real crew members to project roles
- **Start Tasks**: Tasks become active only after all roles are filled
- **Task Management**: Automatic deadline calculation and escalation

### 2. Role & Crew Separation
- **Templates define roles** that need to be filled
- **Crew table** stores actual people details
- **Project roles** are placeholders until filled with real crew members
- **Validation** prevents task start until all roles are assigned

### 3. Task Management
- **Automatic escalation** when deadlines are missed
- **Status tracking**: pending → ongoing → completed/escalated
- **Crew-specific views** showing only assigned tasks
- **Checklist support** with progress tracking

### 4. Access Control
- **Crew members** see only their assigned tasks
- **Project managers** see full project overview
- **Role-based permissions** for task management

## Database Schema

### Core Tables
- `projects`: Main project information with template snapshots
- `project_roles`: Roles required for the project (from templates)
- `project_crew`: Crew members assigned to specific roles
- `project_tasks`: Tasks derived from templates with assignments

### Key Features
- **Automatic triggers** for role count updates
- **Deadline calculation** when tasks are started
- **Escalation triggers** for overdue tasks
- **JSONB support** for flexible data storage

## Components

### ProjectListComponent
- Grid/card view of projects
- Search and filtering
- Progress indicators
- Quick actions (assign crew, view, edit)

### ProjectFormModal
- Create/edit projects
- Template selection with preview
- Image upload support
- Validation and error handling

### ProjectCrewAssignmentModal
- Role-based crew assignment
- Progress tracking for role fulfillment
- Add new crew members on-the-fly
- Role requirement management

### ProjectTaskView
- Task management interface
- Phase-based organization
- Status filtering
- Checklist management
- Crew member task view

## Services

### projectService
- CRUD operations for projects
- Template-based project creation
- Role fulfillment checking

### projectRoleService
- Role requirement management
- Assignment tracking

### projectCrewService
- Crew member assignment
- Role mapping
- Activity tracking

### projectTaskService
- Task lifecycle management
- Assignment and status updates
- Crew member task queries

## Hooks

### useProjects
- Project list management with pagination
- Filtering and search
- CRUD operations

### useProject
- Single project management
- Role fulfillment checking

### useProjectRoles
- Role management for projects
- Requirement updates

### useProjectCrew
- Crew assignment management
- Member lifecycle

### useProjectTasks
- Task management with filtering
- Status updates and assignments

### useCrewMemberTasks
- Personal task view for crew members
- Status management

## Usage

### Basic Project Creation
```tsx
import { useProjects } from './project/project.hook';

const { createProject } = useProjects();

const handleCreate = async () => {
  await createProject({
    project_name: "New Film Project",
    template_id: "template-uuid",
    project_start_date: "2024-01-01"
  }, currentUserId);
};
```

### Crew Assignment
```tsx
import { useProjectCrew } from './project/project.hook';

const { addCrewMember } = useProjectCrew(projectId);

const assignCrew = async () => {
  await addCrewMember({
    project_id: projectId,
    user_id: crewMemberId,
    role_id: roleId,
    is_lead: false
  }, currentUserId);
};
```

### Task Management
```tsx
import { useProjectTasks } from './project/project.hook';

const { startTask, completeTask } = useProjectTasks(projectId);

// Start a task
await startTask(taskId, userId);

// Complete a task
await completeTask(taskId, userId);
```

## Installation & Setup

1. **Run the SQL schema**:
   ```sql
   -- Execute sql/project.sql in your Supabase SQL editor
   ```

2. **Import components**:
   ```tsx
   import Projects from './pages/Projects';
   // or individual components
   import ProjectListComponent from './project/ProjectListComponent';
   ```

3. **Configure routing**:
   ```tsx
   <Route path="/projects" component={Projects} />
   ```

## Business Rules

1. **Projects cannot start tasks until all roles are filled**
2. **Tasks automatically escalate when deadlines are missed**
3. **Crew members only see their assigned tasks**
4. **Role requirements can be adjusted during project setup**
5. **Template snapshots preserve task structure at creation time**

## Future Enhancements

- **File attachments** for tasks
- **Time tracking** for actual hours
- **Project templates** with custom role requirements
- **Notification system** for escalations
- **Reporting and analytics** dashboard
- **Mobile app** for crew task management

## Dependencies

- `@mantine/core`: UI components
- `@mantine/hooks`: React hooks
- `@mantine/form`: Form management
- `@mantine/notifications`: Toast notifications
- `@tabler/icons-react`: Icons
- `supabase`: Database and authentication
