import { useState, useEffect, useCallback } from 'react';
import { notifications } from '@mantine/notifications';
import type {
  ProjectWithStats,
  ProjectRole,
  ProjectCrewWithUser,
  ProjectTaskWithCrew,
  CreateProjectRequest,
  UpdateProjectRequest,
  AddCrewMemberRequest,
  UpdateCrewMemberRequest,
  AssignTaskToCrewRequest,
  UpdateProjectTaskRequest,
  ProjectFilters,
  ProjectTaskFilters,
  ProjectRoleFilters,
  ProjectCrewFilters,
  PaginationParams,
  PaginatedResponse
} from './project.typs';
import {
  projectService,
  projectRoleService,
  projectCrewService,
  projectTaskService
} from './project.service';

// Hook for managing projects
export function useProjects(
  initialFilters: ProjectFilters = {},
  initialPagination: PaginationParams = {}
) {
  const [projects, setProjects] = useState<PaginatedResponse<ProjectWithStats>>({
    data: [],
    count: 0,
    page: 1,
    pageSize: 20,
    totalPages: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<ProjectFilters>(initialFilters);
  const [pagination, setPagination] = useState<PaginationParams>({
    page: 1,
    pageSize: 20,
    ...initialPagination
  });

  const fetchProjects = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await projectService.getPaginated(pagination, filters);
      setProjects(data);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch projects';
      setError(errorMessage);
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
    } finally {
      setLoading(false);
    }
  }, [JSON.stringify(filters), JSON.stringify(pagination)]);

  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  const createProject = async (data: CreateProjectRequest, userId: string, imageUrl?: string) => {
    try {
      setLoading(true);
      await projectService.create(data, userId, imageUrl);
      notifications.show({
        title: 'Success',
        message: 'Project created successfully',
        color: 'green'
      });
      await fetchProjects();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create project';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const updateProject = async (projectId: string, data: UpdateProjectRequest, userId: string) => {
    try {
      await projectService.update(projectId, data, userId);
      notifications.show({
        title: 'Success',
        message: 'Project updated successfully',
        color: 'green'
      });
      await fetchProjects();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update project';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    }
  };

  const archiveProject = async (projectId: string) => {
    try {
      await projectService.archive(projectId);
      notifications.show({
        title: 'Success',
        message: 'Project archived successfully',
        color: 'green'
      });
      await fetchProjects();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to archive project';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    }
  };

  const updateFilters = (newFilters: Partial<ProjectFilters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
    setPagination(prev => ({ ...prev, page: 1 })); // Reset to first page
  };

  const updatePagination = (newPagination: Partial<PaginationParams>) => {
    setPagination(prev => ({ ...prev, ...newPagination }));
  };

  return {
    projects: projects.data,
    totalCount: projects.count,
    currentPage: projects.page,
    totalPages: projects.totalPages,
    pageSize: projects.pageSize,
    loading,
    error,
    filters,
    pagination,
    fetchProjects,
    createProject,
    updateProject,
    archiveProject,
    updateFilters,
    updatePagination
  };
}

// Hook for managing a single project
export function useProject(projectId: string | null) {
  const [project, setProject] = useState<ProjectWithStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchProject = useCallback(async () => {
    if (!projectId) {
      setProject(null);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const data = await projectService.getById(projectId);
      setProject(data);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch project';
      setError(errorMessage);
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    fetchProject();
  }, [fetchProject]);

  const checkAllRolesFilled = async (): Promise<boolean> => {
    if (!projectId) return false;
    
    try {
      return await projectService.areAllRolesFilled(projectId);
    } catch (err) {
      console.error('Failed to check if all roles are filled:', err);
      return false;
    }
  };

  return {
    project,
    loading,
    error,
    fetchProject,
    checkAllRolesFilled
  };
}

// Hook for managing project roles
export function useProjectRoles(projectId: string | null, filters: ProjectRoleFilters = {}) {
  const [roles, setRoles] = useState<ProjectRole[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchRoles = useCallback(async () => {
    if (!projectId) {
      setRoles([]);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const data = await projectRoleService.getByProject(projectId, filters);
      setRoles(data);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch project roles';
      setError(errorMessage);
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
    } finally {
      setLoading(false);
    }
  }, [projectId, JSON.stringify(filters)]);

  useEffect(() => {
    fetchRoles();
  }, [fetchRoles]);

  return {
    roles,
    loading,
    error,
    fetchRoles
  };
}

// Hook for managing project crew
export function useProjectCrew(projectId: string | null, filters: ProjectCrewFilters = {}) {
  const [crew, setCrew] = useState<ProjectCrewWithUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchCrew = useCallback(async () => {
    if (!projectId) {
      setCrew([]);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const data = await projectCrewService.getByProject(projectId, filters);
      setCrew(data);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch project crew';
      setError(errorMessage);
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
    } finally {
      setLoading(false);
    }
  }, [projectId, JSON.stringify(filters)]);

  useEffect(() => {
    fetchCrew();
  }, [fetchCrew]);

  const addCrewMember = async (data: AddCrewMemberRequest, userId: string) => {
    try {
      await projectCrewService.addCrewMember(data, userId);
      notifications.show({
        title: 'Success',
        message: 'Crew member added successfully',
        color: 'green'
      });
      await fetchCrew();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to add crew member';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    }
  };

  const updateCrewMember = async (data: UpdateCrewMemberRequest, userId: string) => {
    try {
      await projectCrewService.updateCrewMember(data, userId);
      notifications.show({
        title: 'Success',
        message: 'Crew member updated successfully',
        color: 'green'
      });
      await fetchCrew();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update crew member';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    }
  };

  const removeCrewMember = async (projectCrewId: string) => {
    try {
      await projectCrewService.removeCrewMember(projectCrewId);
      notifications.show({
        title: 'Success',
        message: 'Crew member removed successfully',
        color: 'green'
      });
      await fetchCrew();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to remove crew member';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    }
  };

  return {
    crew,
    loading,
    error,
    fetchCrew,
    addCrewMember,
    updateCrewMember,
    removeCrewMember
  };
}

// Hook for managing project tasks
export function useProjectTasks(
  projectId: string | null,
  initialFilters: ProjectTaskFilters = {},
  initialPagination: PaginationParams = {}
) {
  const [tasks, setTasks] = useState<PaginatedResponse<ProjectTaskWithCrew>>({
    data: [],
    count: 0,
    page: 1,
    pageSize: 50,
    totalPages: 0
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<ProjectTaskFilters>(initialFilters);
  const [pagination, setPagination] = useState<PaginationParams>({
    page: 1,
    pageSize: 50,
    ...initialPagination
  });

  const fetchTasks = useCallback(async () => {
    if (!projectId) {
      setTasks({
        data: [],
        count: 0,
        page: 1,
        pageSize: 50,
        totalPages: 0
      });
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const data = await projectTaskService.getByProject(projectId, filters, pagination);
      setTasks(data);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch project tasks';
      setError(errorMessage);
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
    } finally {
      setLoading(false);
    }
  }, [projectId, JSON.stringify(filters), JSON.stringify(pagination)]);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const assignToCrew = async (data: AssignTaskToCrewRequest, userId: string) => {
    try {
      await projectTaskService.assignToCrew(data, userId);
      notifications.show({
        title: 'Success',
        message: 'Task assigned successfully',
        color: 'green'
      });
      await fetchTasks();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to assign task';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    }
  };

  const startTask = async (projectTaskId: string, userId: string) => {
    try {
      await projectTaskService.startTask(projectTaskId, userId);
      notifications.show({
        title: 'Success',
        message: 'Task started successfully',
        color: 'green'
      });
      await fetchTasks();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to start task';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    }
  };

  const completeTask = async (projectTaskId: string, userId: string) => {
    try {
      await projectTaskService.completeTask(projectTaskId, userId);
      notifications.show({
        title: 'Success',
        message: 'Task completed successfully',
        color: 'green'
      });
      await fetchTasks();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to complete task';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    }
  };

  const updateTask = async (projectTaskId: string, data: UpdateProjectTaskRequest, userId: string) => {
    try {
      await projectTaskService.updateTask(projectTaskId, data, userId);
      notifications.show({
        title: 'Success',
        message: 'Task updated successfully',
        color: 'green'
      });
      await fetchTasks();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update task';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    }
  };

  const updateFilters = (newFilters: Partial<ProjectTaskFilters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
    setPagination(prev => ({ ...prev, page: 1 })); // Reset to first page
  };

  const updatePagination = (newPagination: Partial<PaginationParams>) => {
    setPagination(prev => ({ ...prev, ...newPagination }));
  };

  return {
    tasks: tasks.data,
    totalCount: tasks.count,
    currentPage: tasks.page,
    totalPages: tasks.totalPages,
    pageSize: tasks.pageSize,
    loading,
    error,
    filters,
    pagination,
    fetchTasks,
    assignToCrew,
    startTask,
    completeTask,
    updateTask,
    updateFilters,
    updatePagination
  };
}

// Hook for crew member's tasks
export function useCrewMemberTasks(userId: string | null) {
  const [tasks, setTasks] = useState<ProjectTaskWithCrew[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchTasks = useCallback(async () => {
    if (!userId) {
      setTasks([]);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const data = await projectTaskService.getTasksByCrewMember(userId);
      setTasks(data);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch your tasks';
      setError(errorMessage);
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const startTask = async (projectTaskId: string) => {
    if (!userId) return;
    
    try {
      await projectTaskService.startTask(projectTaskId, userId);
      notifications.show({
        title: 'Success',
        message: 'Task started successfully',
        color: 'green'
      });
      await fetchTasks();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to start task';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    }
  };

  const completeTask = async (projectTaskId: string) => {
    if (!userId) return;
    
    try {
      await projectTaskService.completeTask(projectTaskId, userId);
      notifications.show({
        title: 'Success',
        message: 'Task completed successfully',
        color: 'green'
      });
      await fetchTasks();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to complete task';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    }
  };

  const updateTask = async (projectTaskId: string, data: UpdateProjectTaskRequest) => {
    if (!userId) return;
    
    try {
      await projectTaskService.updateTask(projectTaskId, data, userId);
      notifications.show({
        title: 'Success',
        message: 'Task updated successfully',
        color: 'green'
      });
      await fetchTasks();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update task';
      notifications.show({
        title: 'Error',
        message: errorMessage,
        color: 'red'
      });
      throw err;
    }
  };

  return {
    tasks,
    loading,
    error,
    fetchTasks,
    startTask,
    completeTask,
    updateTask
  };
}
